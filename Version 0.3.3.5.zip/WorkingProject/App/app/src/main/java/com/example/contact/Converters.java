package com.example.contact;

import androidx.room.TypeConverter;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

//Class used to convert ArrayList<Contact> to strings for storing in the Database


public class Converters
{
    /* This method takes our arraylist object as parameter and returns string representation for it so that it can be stored in Room Database.
     * Very simple and easy way to convert any object to string is converting it into its JSON equivalent.
     * Just creating Gson object and calling toJson method with our object as parameter is enough.
     */

    @TypeConverter
    public static ArrayList<Contact> fromTimestamp(String value)
    {
        Type listType = new TypeToken<ArrayList<Contact>>() {}.getType();

        return new Gson().fromJson(value, listType);
        // return value == null ? null : new Date(value);
    }

    /* While reading data back from Room Database, we get JSON form of our arraylist which we need to convert back. We will use Gson method from Json by providing JSON string as parameter.
     * But while converting back, we also need to provide the class of original object (in our case, arraylist),
     * but providing arraylist is not enough here as Gson will not be able know what kind of list it has to form.
     * That’s why we used Type to provide the type of list we want Gson to form for us from the JSON string.
     */


    @TypeConverter
    public static String arraylistToString(ArrayList<Contact> list)
    {
        Gson gson = new Gson();
        String json = gson.toJson(list);

        return json;
        // return date == null ? null : date.getTime();
    }
}
