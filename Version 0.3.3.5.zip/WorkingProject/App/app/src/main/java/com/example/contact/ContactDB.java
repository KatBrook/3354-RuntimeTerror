package com.example.contact;
import android.content.Context;
import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;
import androidx.sqlite.db.SupportSQLiteDatabase;

/*
Contains the database holder and serves as the main access point for the underlying connection
to your app's persisted relational data.

Class should be abstract and extend RoomDatabase, it should include the list of entities
associated with the database, and it should contain an abstract method that returns the class
that is associated with @Dao
*/

@Database(entities = {Contact.class, Group.class}, version = 1)
//@TypeConverters({Converters.class})
public abstract class ContactDB extends RoomDatabase
{
    private static final String DB_NAME = "contact-db";
    private static ContactDB INSTANCE;

    public abstract ContactDao contactDao();
    public abstract GroupDao groupDao();

    /*
    Synchronized means only one thread can access the method at a time, avoiding getting two
    instances of database when two separate threads reference this method
    */

    public static synchronized ContactDB getInstance(Context context)
    {
        if(INSTANCE == null)
        {
            //Build database if instantiation does not exist
            INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                            ContactDB.class,
                                            DB_NAME)
                                            .fallbackToDestructiveMigration()
                                            .addCallback(roomCallback)
                                            .build();
        }
        return INSTANCE;
    }

    //Populate database with dummy info for testing
    private static RoomDatabase.Callback roomCallback = new RoomDatabase.Callback()
    {
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db)
        {
            super.onCreate(db);
            new PopulateDbAsyncTask(INSTANCE).execute();
        }
    };


    private static class PopulateDbAsyncTask extends AsyncTask<Void, Void, Void>
    {
        private ContactDao contactDao;
        private GroupDao groupDao;

        private PopulateDbAsyncTask(ContactDB contactDB)
        {
            contactDao = contactDB.contactDao();
            groupDao = contactDB.groupDao();
        }

        @Override
        protected Void doInBackground(Void... voids)
        {
            contactDao.insertContact(new Contact(null, "Bruce Wayne", "735-185-7301", null, "5550592389", "Bruce.Wayne@gotham.com", "1007 Mountain Drive"));
            contactDao.insertContact(new Contact(null, "John Doe", "5558675309", "5551234567", "5559876543", "John.Doe@gmail.com", "123 Fake Street."));
            contactDao.insertContact(new Contact(null, "Tony Stark", "678-136-7092", null, null, "Tony.Stark@avengers.com", "10880 Malibu Point"));

            return null;
        }
    }
}


