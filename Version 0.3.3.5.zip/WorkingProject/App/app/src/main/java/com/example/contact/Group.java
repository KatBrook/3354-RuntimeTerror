package com.example.contact;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

import 	java.util.ArrayList;

@Entity
@TypeConverters({Converters.class})
public class Group
{/*
    private @PrimaryKey @NonNull String id;

    @NonNull
    public String getId()
    {
        return id;
    }
    @NonNull
    public void setId(String id)
    {
        this.id = id;
    }
    */

    @PrimaryKey(autoGenerate = true)
    private int id;

    private String groupImagePath;
    private String groupName;
    //private ArrayList<Contact> groupMembers;
    private ArrayList<Contact> groupMembers = new ArrayList<>();

    public Group(String groupImagePath, String groupName, ArrayList<Contact> groupMembers)
    {
        this.groupImagePath = groupImagePath;
        this.groupName = groupName;

        //if ArrayList is not null and empty
        if(groupMembers != null && !groupMembers.isEmpty())
        {
            this.groupMembers.addAll(groupMembers);
        }
        //If ArrayList is null or empty
        else
        {
            //Add John Doe the default user

            Contact defaultContact = new Contact(null, "John Doe", "5558675309", "5551234567", "5559876543", "John.Doe@gmail.com", "123 Fake Street.");

            this.groupMembers.add(defaultContact);
        }
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public int getId()
    {
        return id;
    }

    public String getGroupImagePath()
    {
        return groupImagePath;
    }

    public String getGroupName()
    {
        return groupName;
    }

    public ArrayList<Contact> getGroupMembers()
    {
        return groupMembers;
    }
}
