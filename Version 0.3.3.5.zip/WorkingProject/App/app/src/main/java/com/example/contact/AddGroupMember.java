package com.example.contact;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageDecoder;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;


public class AddGroupMember extends AppCompatActivity implements RecyclerItemTouchHelper.RecyclerItemTouchHelperListener, RecyclerItemGroupTouchHelper.RecyclerItemTouchHelperListener
{

    private EditText groupName;
    private ImageView groupPhoto;
    private ArrayList<Contact> groupMembers; //was EditText instead of ArrayList<Contact> groupMembers

    private ArrayAdapter<Contact> memberAdapter;
    private ListView members; // = groupMembers

    private ContactViewModel contactViewModel;
    private GroupViewModel groupViewModel;
    private ContactAdapter contactAdapter;
    private GroupAdapter groupAdapter;

    //private GroupViewModel groupMemberViewModel;
    //private GroupAdapter groupMemberAdapter;

    //Key to send back contact information back and forth between MainActivity and this.

    public static final String GROUP_ID = "com.example.group.GROUP_ID";
    //public static final String GROUP_NAME = "com.example.group.GROUP_NAME";
    //public static final String GROUP_PHOTO = "com.example.group.GROUP_PHOTO";
    public static final String GROUP_MEMBERS = "com.example.group.GROUP_MEMBERS";

    //-----------------------------------onCreate-----------------------------------//
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_list);

        //Populate Recycle view

        populateContacts();

        //Have layout move up when keyboard appears

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

        //Get IDs and assign to variables

        createIDs();

    } //End of OnCreate function

    //---------------------------------Populate Contacts---------------------------------//

    private void populateContacts()
    {
        //Set up RecycleView

        //Regular contact

        RecyclerView recyclerContactView = findViewById(R.id.contact_list);
        recyclerContactView.setLayoutManager(new LinearLayoutManager(this)); //Every RecyclerView needs a layout manager
        recyclerContactView.setHasFixedSize(true);

        contactAdapter = new ContactAdapter();
        recyclerContactView.setAdapter(contactAdapter); //Populate RecyclerView with list of contacts in adapter

        //Gain access to ContactViewModel

        contactViewModel = new ViewModelProvider(this).get(ContactViewModel.class);

        //If activity is in foreground and list of contacts have changed, update RecyclerView

        contactViewModel.getAllContacts().observe(this, new Observer<List<Contact>>()
        {
            @Override
            public void onChanged(List<Contact> contacts)
            {
                //Updates RecyclerView whenever there is a change in the list of contacts

                contactAdapter.setContacts(contacts);
            }
        });


        //When a contact is clicked on add it to the group member list

        contactAdapter.setOnItemClickListener(new ContactAdapter.OnItemClickListener()
        {
            @Override
            public void onItemClick(Contact contact)
            {
                //User touched a contact to add
                //If box next to contact was checked add as a group member

                Intent intent = new Intent(AddGroupMember.this, AddEditGroupContact.class); //When a contact is clicked on it doesn't add, it refreshes the page

                //Pass data from group object to AddEditGroup Activity for Editing
                //intent.putExtra(GROUP_ID, id); //Pass to AddEditContact to later pass back to MainActivity in order to tell database what contact to update
                //intent.putExtra(GROUP_NAME, groupName);
                intent.putExtra(GROUP_PHOTO, imageFilePath);
                intent.putExtra(GROUP_MEMBERS, groupMembers);
                startActivityForResult(intent, ADD_GROUP_MEMBER_REQUEST);

                //addGroupMembers(contact);

                //Go back to AddEditView or exit activity

            }
        });

        ItemTouchHelper.SimpleCallback itemTouchHelperCallbackContact = new RecyclerItemTouchHelper(0, ItemTouchHelper.LEFT, this);
        new ItemTouchHelper(itemTouchHelperCallbackContact).attachToRecyclerView(recyclerContactView);

        //Display all created contacts

        displayContacts();

    }


    //------------------------------Display Contacts to Add------------------------------//

    private void displayContacts()
    {
        //Displays contacts in alphabetical order, sorted by first letter of username

        LinearLayout contactsLayout = findViewById(R.id.contactLayout);

        for(int i = 0; i < letterTextViews().size(); i++)
        {
            contactsLayout.addView(letterTextViews().get(i));
        }
    }

    private List<TextView> letterTextViews()
    {
        List<TextView> lettersArray = new ArrayList<TextView>();

        //Go through letters
        for(int letter = 0; letter < letters.length; letter++) //Cycle through letters
        {
            //Create a TextViewContext
            TextView textView = new TextView(getApplication()); //Create textView instance

            //Create the layout for the TextView
            RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(
                    RelativeLayout.LayoutParams.MATCH_PARENT, //Width
                    RelativeLayout.LayoutParams.WRAP_CONTENT //Height
            );

            //Add the layout properties to the TextView
            textView.setLayoutParams(lp);
            textView.setPadding(5,5,5,5);

            //Set the text of the TextView equal to the letter
            textView.setText(letters[letter]);
            lettersArray.add(textView);
        }
        return lettersArray;
    }

    //--------------------------Adding a group member.--------------------------------//

    private void addGroupMembers(Contact contact)
    {
        //Implements functionality for when request codes are sent

        //If requestCode to add group member is sent and there is no error

        //Add contact to groupMembers arraylist

        //Add group member to arraylist/list view

        //ArrayList<Contact> groupMembers = data.getParcelableExtra(AddEditGroupContact.GROUP_MEMBERS);
        //Contact result = data.getParcelableExtra(AddEditGroupContact.GROUP_MEMBERS);
        //groupMembers.add(result);

        //If a contact is already a group member do not add them again

        if(groupMembers.contains(contact))
        {
            //Do nothing

            //Display toast informing user that contact was already added.
            Toast.makeText(this, "Group Member already added", Toast.LENGTH_SHORT).show();
        }
        else
        {
            groupMembers.add(contact);
            memberAdapter.notifyDataSetChanged();

            //Display toast informing user that contact was added.
            Toast.makeText(this, "Group Member added", Toast.LENGTH_SHORT).show();
        }

        //Retrieve contact information from AddEditGroupContact page
        //String groupPhoto = data.getStringExtra(AddEditGroupContact.GROUP_PHOTO);
        //String groupName = data.getStringExtra(AddEditGroupContact.GROUP_NAME);

        //ArrayList<Group> groupMembers = data.getExtras(AddEditGroupContact.GROUP_MEMBERS); //Edit
        //ArrayList<Contact> groupMembers = data.getParcelableExtra(AddEditGroupContact.GROUP_MEMBERS); //Edit

        //Add fields to contact object

        //Group group = new Group(groupPhoto, groupName, groupMembers);

    }

    //-----------------------------------EditText IDs-----------------------------------//
    private void createIDs()
    {
        //Contact information
        groupName = findViewById(R.id.groupNameInput);
        groupPhoto = findViewById(R.id.groupPhoto);
        //groupMembers = findViewById(R.id.groupMembersInput);

        //Give each group member an id

        //for(int i = 0; i < groupMembers.size(); i++)
        //{
            //groupMembers.get(i) = findViewById(R.id.groupMembers);
        //}

        members = findViewById(R.id.viewMembers);

        //Set up listview

        groupMembers = new ArrayList<Contact>();
        memberAdapter = new ArrayAdapter<Contact>(AddGroupMember.this, android.R.layout.simple_list_item_1, groupMembers);
        members.setAdapter(memberAdapter);
    }

    private void determineIntent() //Determines intent. If add, set title to add, if edit, set title to edit and fill out fields with existing contact info
    {
        Intent intent = getIntent();

        //Determine if the contact information activity was opened with the intention of adding or editing a contact

        if(intent.hasExtra(GROUP_ID))
        {
            //Set title to specify edit

            setTitle("Edit Group");

            //Fill out fields with existing contact data

            groupName.setText(intent.getStringExtra(GROUP_NAME));

            //Get contact file path, convert to bitmap and set ImageView to bitmap

            if(intent.getStringExtra(GROUP_PHOTO) != null) //If an image exists for the contact
            {
                try //If there is no error in getting file, convert to bitmap and set ImageViewer to display it
                {
                    Bitmap selectedImage = BitmapFactory.decodeStream(new FileInputStream(new File(intent.getStringExtra(GROUP_PHOTO))));
                    //contactPhoto.setImageBitmap(selectedImage);
                    groupPhoto.setImageBitmap(selectedImage);
                }
                catch(FileNotFoundException e) //If there is an error in displaying file, set photo to default image
                {
                    e.printStackTrace();
                    //contactPhoto.setImageResource(R.drawable.ic_user);
                    groupPhoto.setImageResource(R.drawable.ic_user);
                }
            }
            else //If no image was passed, since no image was ever selected for contact, set image to default user photo
            {

            }

            //Fill group member list with existing group members

            //groupMembers.setText(intent.getStringExtra(GROUP_MEMBERS)); ////////////////////////////////////////Need to fix
            //groupMembers.setText(intent.getParcelableExtra(GROUP_MEMBERS));

            //members.setAdapter(memberAdapter);

            displayGroupMembers();


        }
        else //If not edit, then activity was started to add contact
        {
            //Set title to specify add
            setTitle("Add Group");
        }
    }

