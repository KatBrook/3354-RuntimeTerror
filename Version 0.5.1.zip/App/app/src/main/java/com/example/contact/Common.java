package com.example.contact;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Common
{
    public static final int VIEWTYPE_CONTACT = 9000;
    public static final int VIEWTYPE_LETTER = 9001;
    public static final int RESULT_CODE = 9002;
    public static final String LETTER_SELECTED = "com.example.contact.LETTER_SELECTED";

    public static final String CONTACT_ID = "com.example.contact.CONTACT_ID";
    public static final String CONTACT_USERNAME = "com.example.contact.CONTACT_USERNAME";
    public static final String CONTACT_PHOTO = "com.example.contact.CONTACT_PHOTO";
    public static final String CONTACT_MOBILE = "com.example.contact.CONTACT_MOBILE";
    public static final String CONTACT_HOME = "com.example.contact.CONTACT_HOME";
    public static final String CONTACT_WORK = "com.example.contact.CONTACT_WORK";
    public static final String CONTACT_EMAIL = "com.example.contact.CONTACT_EMAIL";
    public static final String CONTACT_ADDRESS = "com.example.contact.CONTACT_ADDRESS";
    public static final String CONTACT_BLACKLISTED = "com.example.contact.BLACKLISTED";

    public static List<String> alphabet_available = new ArrayList<>();


    //Sort list of contacts alphabetically
    public static List<Contact> sortList(List<Contact> contact)
    {
        Collections.sort(contact, new Comparator<Contact>()
        {
            @Override
            public int compare(Contact o1, Contact o2)
            {
                return o1.getName().compareTo(o2.getName());
            }
        });
        return contact;
    }

    //Get characters to display above contacts
    public static List<Contact> addAlphabets(List<Contact> list)
    {
        ArrayList<Contact> customList = new ArrayList<>();

        //Make sure list isn't null
        if(!list.isEmpty())
        {
            int i;
            Contact firstPosition;

            if(list.get(0).getName() != null && !list.get(0).getName().isEmpty())
            {
                firstPosition = new Contact(String.valueOf(list.get(0).getName().toUpperCase().charAt(0)), VIEWTYPE_LETTER);
                alphabet_available.add(String.valueOf(list.get(0).getName().toUpperCase().charAt(0))); //Add first character of contact to contact header list
            }
            else //If name is null
            {
                firstPosition = new Contact(String.valueOf('#'), VIEWTYPE_LETTER); //Assign '#' as Char so contacts with no names appear under '#' header
                alphabet_available.add("#"); //Add first character of contact to contact header list
            }

            customList.add(firstPosition);

            for(i = 0; i < list.size() - 1; i++)
            {
                char name1;
                char name2;

                if(list.get(i).getName() != null && !list.get(i).getName().isEmpty())
                {
                    name1 = list.get(i).getName().toUpperCase().charAt(0); //Get first character in name
                }
                else //If name is null
                {
                    name1 = '#';
                }

                if(list.get(i + 1).getName() != null && !list.get(i + 1).getName().isEmpty())
                {
                    name2 = list.get(i + 1).getName().toUpperCase().charAt(0); //Get first character in next name
                }
                else //If name is null
                {
                    name2 = '#';
                }


                if(name1 == name2)
                {
                    customList.add(list.get(i)); //If next contact has same first letter in name, add to list as default contact
                }
                else //If first letter of next context is different than first letter of current contact, specify contact as a letter
                {
                    customList.add(list.get(i));
                    Contact contact = new Contact(String.valueOf(name2), VIEWTYPE_LETTER);
                    alphabet_available.add(String.valueOf(name2));
                    customList.add(contact);
                }
            }
            customList.add(list.get(i));
        }

        return customList;
    }

    //Returns position of contact (by name) in list
    public static int findPositionWithName(String name, List<Contact> list)
    {
        for(int i = 0; i < list.size(); i++)
        {
            if(list.get(i).getName().toUpperCase().equals(name))
            {
                return i;
            }
        }
        return -1; //If name not found
    }

    //Creates Alphabet list
    public static List<String> generateAlphabet()
    {
        ArrayList<String> result = new ArrayList<>();
        for(int i = 65; i <= 90; i++) //A = 65 in ASCII and Z = 90 in ASCII
        {
            char character = (char) i;
            result.add(String.valueOf(character));
        }

        return result;
    }

}
