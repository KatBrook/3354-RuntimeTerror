package com.example.contact;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Group
{/*
    private @PrimaryKey @NonNull String id;

    @NonNull
    public String getId()
    {
        return id;
    }
    @NonNull
    public void setId(String id)
    {
        this.id = id;
    }
    */

    @PrimaryKey(autoGenerate = true)
    private int id;

    private String contactImagePath;
    private String groupName;

    public Group(String contactImagePath, String groupName)
    {
        this.contactImagePath = contactImagePath;
        this.groupName = groupName;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public int getId()
    {
        return id;
    }

    public String getContactImagePath()
    {
        return contactImagePath;
    }

    public String getGroupName()
    {
        return groupName;
    }
}
