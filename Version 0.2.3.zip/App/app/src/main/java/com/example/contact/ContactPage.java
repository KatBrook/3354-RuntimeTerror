package com.example.contact;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

public class ContactPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_page);
    }

    //When save button is pressed, save contact info
    public void saveContactInfo(View view)
    {
        //Save contact information entered into instance of contact class
        Contact contact = contactInformation();
        //Call Contact Database
        ContactDB contactDB = ContactDB.getInstance();
        //Store information into database
        contactDB.addContactInfo(contact);
    }

    public Contact contactInformation()
    {
        //Create instantiation of Contact Class
        Contact contact = new Contact();

        //Contact Name
        EditText userNameInput = findViewById(R.id.userNameInput);
        String userName = userNameInput.getText().toString();
        contact.setName(userName);

        //Contact Photo
        ImageView userImageInput = findViewById(R.id.contactPhoto);
        Bitmap userImage = userImageInput.getDrawingCache();
        contact.setContactImage(userImage);

        //Contact Cell Number
        EditText cellNumInput = findViewById(R.id.mobileNumInput);
        String cellNum = cellNumInput.getText().toString();
        contact.setMobileNumber(cellNum);

        //Contact Home Number
        EditText homeNumInput = findViewById(R.id.homeNumInput);
        String homeNum = homeNumInput.getText().toString();
        contact.setHomeNumber(homeNum);

        //Contact Work Number
        EditText workNumInput = findViewById(R.id.workNumInput);
        String workNum = workNumInput.getText().toString();
        contact.setWorkNumber(workNum);

        //Contact Email
        EditText emailInput = findViewById(R.id.emailInput);
        String email = emailInput.getText().toString();
        contact.setEmailAddress(email);

        //Contact Address
        EditText addressInput = findViewById(R.id.addressInput);
        String address = addressInput.getText().toString();
        contact.setAddress(address);

        return contact;
    }

    //If "cancel" button is pressed, return to main activity
    public void openMainActivity(View view)
    {
        Intent openMainActivityIntent = new Intent(this, MainActivity.class);
        startActivity(openMainActivityIntent);
    }

}
