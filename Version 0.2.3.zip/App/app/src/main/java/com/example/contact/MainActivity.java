package com.example.contact;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ActionBar;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity{
    private final String[] letters = {"A","B","C","D","E","F","G","H","I","J","K","L","M",
                                    "N","O","P","Q","R","S","T","U","V","W","X","Y","Z","#"};

    //Sets the layout
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        displayUserInfo();
        displayLetters();
        displayContacts();
    }

    public void displayUserInfo()
    {
        //------------------User Photo and Name------------------

        TextView user = findViewById(R.id.userName);
        user.setText("Test Name");
    }

    public void displayLetters()
    {
        //------------------Create Letters------------------

        //Get ID of layout that will hold letters
        LinearLayout lettersLayout = findViewById(R.id.letterLayout);

        //Go through letters
        for(int letter = 0; letter < letters.length; letter++) //Cycle through letters
        {
            //Create a TextView
            TextView textView = new TextView(getApplicationContext()); //Create textView instance

            //Create the layout for the TextView
            RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(
                    RelativeLayout.LayoutParams.MATCH_PARENT, //Width
                    RelativeLayout.LayoutParams.WRAP_CONTENT //Height
            );

            //Add the layout properties to the TextView
            textView.setLayoutParams(lp);
            textView.setPadding(5,5,5,5);

            //Set the text of the TextView equal to the letter
            textView.setText(letters[letter]);

            //Add TextView to Layout
            lettersLayout.addView(textView);
        }
    }

    public void displayContacts()
    {

    }


    //Open Contact Page to add Contact Information
    public void openContactPage(View view)
    {
        Intent openContactPageIntent = new Intent(this, ContactPage.class);
        startActivity(openContactPageIntent);
    }
}
