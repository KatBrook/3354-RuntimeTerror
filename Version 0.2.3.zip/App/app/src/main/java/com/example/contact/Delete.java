package com.example.contact;

public class Delete extends Contact
{

}
