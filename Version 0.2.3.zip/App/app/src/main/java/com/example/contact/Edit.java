package com.example.contact;

public class Edit extends Contact
{

}
