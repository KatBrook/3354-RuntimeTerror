package com.example.contact;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;

import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.UUID;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;


public class ContactPage extends AppCompatActivity {
    private String userName;
    private ImageView contactPhoto;
    private String cellNum;
    private String homeNum;
    private String workNum;
    private String email;
    private String address;
    private TextView primaryText;

    private Button textButton;
    private Button callButton;
    private Button emailButton;

    private Button editButton;
    private Button deleteButton;
    private Button blacklistButton;

    private String imageFilePath;

    public static final String CONTACT_ID = "com.example.contact.CONTACT_ID";
    public static final String CONTACT_USERNAME = "com.example.contact.CONTACT_USERNAME";
    public static final String CONTACT_PHOTO = "com.example.contact.CONTACT_PHOTO";
    public static final String CONTACT_MOBILE = "com.example.contact.CONTACT_MOBILE";
    public static final String CONTACT_HOME = "com.example.contact.CONTACT_HOME";
    public static final String CONTACT_WORK = "com.example.contact.CONTACT_WORK";
    public static final String CONTACT_EMAIL = "com.example.contact.CONTACT_EMAIL";
    public static final String CONTACT_ADDRESS = "com.example.contact.CONTACT_ADDRESS";

    public static final int EDIT_CONTACT_REQUEST = 2001;


    //-----------------------------------onCreate-----------------------------------//
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_page);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        createIDs();
        getContactData();
        displayPrimaryInfo();

    }

    private void createIDs()
    {
        //Buttons
        textButton = findViewById(R.id.textButton);
        callButton = findViewById(R.id.callButton);
        emailButton = findViewById(R.id.emailButton);
        editButton = findViewById(R.id.editButton);
        deleteButton = findViewById(R.id.deleteButton);
        blacklistButton = findViewById(R.id.blacklistButton);
        primaryText = findViewById(R.id.primaryText);
    }

    public void getContactData()
    {
        Intent intent = getIntent();
        if(intent != null)
        {
            userName = intent.getStringExtra(CONTACT_USERNAME);
            cellNum = intent.getStringExtra(CONTACT_MOBILE);
            homeNum = intent.getStringExtra(CONTACT_HOME);
            workNum = intent.getStringExtra(CONTACT_WORK);
            email = intent.getStringExtra(CONTACT_EMAIL);
            address = intent.getStringExtra(CONTACT_ADDRESS);
        }
    }

    public void displayPrimaryInfo()
    {
        if(userName != null && !userName.isEmpty())
        {
            primaryText.setText(userName);
        } else if(cellNum != null && !cellNum.isEmpty())
        {
            primaryText.setText(cellNum);
        } else if(homeNum != null && !homeNum.isEmpty())
        {
            primaryText.setText(homeNum);
        } else if(workNum != null && !workNum.isEmpty())
        {
            primaryText.setText(workNum);
        } else if(email != null && !email.isEmpty())
        {
            primaryText.setText(email);
        } else if(address != null && !address.isEmpty())
        {
            primaryText.setText(address);
        }
    }

    public void backButtonPressed(View view)
    {
        Intent openMainActivityIntent = new Intent(this, MainActivity.class);
        startActivity(openMainActivityIntent);
    }

    public void textButtonPressed(View view)
    {

    }

    public void callButtonPressed(View view)
    {

    }

    public void emailButtonPressed(View view)
    {

    }

    public void editButtonPressed(View view)
    {
        Intent intent = new Intent(ContactPage.this, AddEditContact.class);
        startActivityForResult(intent, EDIT_CONTACT_REQUEST);
    }

    public void deleteButtonPressed(View view)
    {

    }

    public void blacklistButtonPressed(View view)
    {

    }
}
