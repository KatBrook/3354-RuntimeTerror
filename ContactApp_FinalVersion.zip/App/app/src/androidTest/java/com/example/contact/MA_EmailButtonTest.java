package com.example.contact;

import android.content.Intent;

import androidx.test.espresso.intent.rule.IntentsTestRule;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.intent.Intents.intended;
import static androidx.test.espresso.intent.matcher.IntentMatchers.toPackage;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class MA_EmailButtonTest {
    //Make intent.
    public IntentsTestRule<ContactPage> contactPageIntentTestRule = new IntentsTestRule<>(ContactPage.class);
    private ContactPage contactPageIntent = null;

    //Instantiate contactPageIntent
    @Before
    public void setUp()
    {
        contactPageIntent = contactPageIntentTestRule.getActivity();
    }

    //Test method for email button.
    @Test
    public void emailButtonPressed()
    {
        //Check emial button is displayed.
        if(withId(R.id.emailButton).matches(isDisplayed()))
        {
            //Click email button.
            onView(withId(R.id.textButton)).perform(click());

            Intent actionView = new Intent(Intent.ACTION_VIEW);

            //If conttact page does not perform action View, button disabled.
            if(contactPageIntent.getIntent() != actionView)
            {
                System.out.println("Email button is disabled");
            } else
            {
                intended(toPackage("com.sec.android.email"));
            }
        } else
        {
            System.out.println("Email button is not displayed");
        }
    }

    //Reset contactPageIntent.
    @After
    public void tearDown()
    {
        contactPageIntent = null;
    }
}
