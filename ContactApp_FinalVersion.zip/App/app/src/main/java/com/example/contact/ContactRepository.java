package com.example.contact;

import android.app.Application;
import android.os.AsyncTask;
import androidx.lifecycle.LiveData;
import java.util.List;
import java.util.concurrent.ExecutionException;

/*
Provides abstraction layer between Room database and app
Instead of user calling database and having to make async task calls every time,
this class is called instead which performs the calls for the user.
*/
public class ContactRepository
{
    //LiveData lets components in your app (usually the UI) observe LiveData objects for changes
    private ContactDao contactDao;
    private LiveData<List<Contact>> allContacts;

    //Application (subclass of context) is passed in to use as context for database instance
    public ContactRepository(Application application)
    {
        ContactDB database = ContactDB.getInstance(application);

        //Set contactDao object equal to instance of database
        contactDao = database.contactDao();

        allContacts = contactDao.getAllContacts();
    }

    //These are the methods that make up the API which the repository exposes to the outside
    public void insertContact(Contact contact)
    {
        new InsertContactAsyncTask(contactDao).execute(contact);
    }

    public void updateContact(Contact contact)
    {
        new UpdateContactAsyncTask(contactDao).execute(contact);
    }

    public void deleteContact(Contact contact)
    {
        new DeleteContactAsyncTask(contactDao).execute(contact);
    }

    public Contact getContactById(String contactID)
    {
        try
        {
            return new GetContactByIdAsyncTask(contactDao).execute(contactID).get();
        }
        catch (ExecutionException e)
        {
            e.printStackTrace();
            return null;
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
            return null;
        }
    }

    public LiveData<List<Contact>> getAllContacts()
    {
        return allContacts;
    }


    //Room doesn't allow operations on main thread. AsycTask creates background thread
    private static class GetContactByIdAsyncTask extends AsyncTask<String, Void, Contact>
    {
        private ContactDao contactDao;

        private GetContactByIdAsyncTask(ContactDao contactDao) { this.contactDao = contactDao; }

        @Override
        protected Contact doInBackground(String... strings)
        {
            return contactDao.getContactById(strings[0]);
        }
    }

    private static class InsertContactAsyncTask extends AsyncTask<Contact, Void, Void>
    {
        private ContactDao contactDao;

        private InsertContactAsyncTask(ContactDao contactDao)
        {
            this.contactDao = contactDao;
        }

        //The dots are called "Vargas." This is for methods that need to take a variable number (0 to n) of arguments
        @Override
        protected Void doInBackground(Contact... contacts)
        {
            //0 because only one contact is being passed in, at index 0
            contactDao.insertContact(contacts[0]);
            return null;
        }
    }

    private static class UpdateContactAsyncTask extends AsyncTask<Contact, Void, Void>
    {
        private ContactDao contactDao;

        private UpdateContactAsyncTask(ContactDao contactDao)
        {
            this.contactDao = contactDao;
        }

        //The dots are called "Vargas." This is for methods that need to take a variable number (0 to n) of arguments
        @Override
        protected Void doInBackground(Contact... contacts)
        {
            //0 because only one contact is being passed in, at index 0
            contactDao.updateContact(contacts[0]);
            return null;
        }
    }

    private static class DeleteContactAsyncTask extends AsyncTask<Contact, Void, Void>
    {
        private ContactDao contactDao;

        private DeleteContactAsyncTask(ContactDao contactDao)
        {
            this.contactDao = contactDao;
        }

        //The dots are called "Vargas." This is for methods that need to take a variable number (0 to n) of arguments
        @Override
        protected Void doInBackground(Contact... contacts)
        {
            //0 because only one contact is being passed in, at index 0
            contactDao.deleteContact(contacts[0]);
            return null;
        }
    }


}
