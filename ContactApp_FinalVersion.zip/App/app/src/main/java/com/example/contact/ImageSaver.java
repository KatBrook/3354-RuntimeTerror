package com.example.contact;

import android.content.Context;
import android.content.ContextWrapper;
import android.graphics.Bitmap;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

//Used to save image selected for contact or group to file for later retrieval
public class ImageSaver
{
    private Bitmap bitmapImage;
    private Context context;
    private String imageName;

    public ImageSaver(Bitmap bitmapImage, Context context, String imageName)
    {
        this.bitmapImage = bitmapImage;
        this.context = context;
        this.imageName = imageName;
    }

    public String saveToInternalStorage()
    {
        ContextWrapper cw = new ContextWrapper(context);
        //path to /data/data/(our app)/app_data/imageDir This is a private folder that every app gets
        File directory = cw.getDir("imageDir", Context.MODE_PRIVATE);
        //Create imageDir
        File myPath = new File(directory, imageName + ".jpg");

        FileOutputStream fos = null;
        try
        {
            fos = new FileOutputStream(myPath);
            //Write image to OutputStream
            bitmapImage.compress(Bitmap.CompressFormat.PNG, 100, fos);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                //Close output stream
                fos.close();
            }
            catch(IOException e)
            {
                e.printStackTrace();
            }
        }
        return myPath.getAbsolutePath(); //Return path to image
    }

}
