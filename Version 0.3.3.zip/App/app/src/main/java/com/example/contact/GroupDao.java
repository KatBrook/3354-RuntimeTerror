package com.example.contact;

import androidx.room.Dao;

@Dao
public interface GroupDao
{

}
