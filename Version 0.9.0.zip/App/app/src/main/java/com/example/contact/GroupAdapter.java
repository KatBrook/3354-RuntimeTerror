package com.example.contact;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.amulyakhare.textdrawable.TextDrawable;
import com.amulyakhare.textdrawable.util.ColorGenerator;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

/*
Allows you to enter list of groups into RecycleView
GroupAdapter.groupHolder is passed in so the RecyclerView Adapter knows this is the view holder we want to use
 */
public class GroupAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> implements Filterable
{
    private List<Group> groupList = new ArrayList<>();
    private List<Group> groupListFull;

    private OnItemClickListener listener;

    @NonNull
    @Override //Where you create and return a group holder
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewTypeGroup)
    {
        //Parent is the ViewGroup parameter in the method. This is the RecyclerView
        LayoutInflater inflater = LayoutInflater.from(viewGroup.getContext());
        if(viewTypeGroup == Common.VIEWTYPE_GROUP)
        {
            ViewGroup groupView = (ViewGroup)inflater.inflate(R.layout.group_item, viewGroup, false);
            GroupViewHolder groupViewHolder = new GroupViewHolder(groupView);
            return groupViewHolder;
        }
        else if(viewTypeGroup == Common.VIEWTYPE_LETTER_GROUP)
        {
            ViewGroup letterViewGroup = (ViewGroup)inflater.inflate(R.layout.letter_item, viewGroup, false);
            LetterViewHolderGroup letterViewHolderGroup = new LetterViewHolderGroup(letterViewGroup);
            return letterViewHolderGroup;
        }
        else
        {
            ViewGroup letterViewGroup = (ViewGroup)inflater.inflate(R.layout.letter_item, viewGroup, false);
            LetterViewHolderGroup letterViewHolderGroup = new LetterViewHolderGroup(letterViewGroup);
            return letterViewHolderGroup;
        }
    }

    @Override //This is where we pull data from each Group object and put it into the views of the GroupHolder
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int position)
    {
        if(viewHolder instanceof GroupViewHolder)
        {
            GroupViewHolder groupViewHolder = (GroupViewHolder) viewHolder;
            Group currentGroup = groupList.get(position);

            //Set card name equal to group name
            if(currentGroup.getGroupName() != null && !currentGroup.getGroupName().isEmpty()) //If name was entered for group
            {
                groupViewHolder.groupName.setText(currentGroup.getGroupName()); //Set name equal to group name
            }
            else //If no name was entered for group
            {
                groupViewHolder.groupName.setText(R.string.unknown_name);
            }

            //Set card photo equal to group photo
            if(currentGroup.getGroupImagePath() != null && !currentGroup.getGroupImagePath().isEmpty()) //If image was selected for group
            {
                try //If there is no error in getting file, convert to bitmap and set ImageViewer to display it
                {
                    Bitmap selectedImage = BitmapFactory.decodeStream(new FileInputStream(new File(currentGroup.getGroupImagePath())));
                    groupViewHolder.groupPhoto.setImageBitmap(selectedImage); //Set photo to selected image
                }
                catch(FileNotFoundException e) //If there is an error in displaying file, set photo to default image
                {
                    e.printStackTrace();
                    //Check for group name. If one exists, set image to first letter.
                    if(currentGroup.getGroupName() != null && !currentGroup.getGroupName().isEmpty())
                    {
                        ColorGenerator generator = ColorGenerator.MATERIAL;
                        TextDrawable drawable = TextDrawable
                                .builder()
                                .beginConfig()
                                .width(96)
                                .height(96)
                                .endConfig()
                                .buildRound(String.valueOf(currentGroup.getGroupName().charAt(0)), generator.getRandomColor());
                        groupViewHolder.groupPhoto.setImageDrawable(drawable);
                    }
                }
            }
            else //If no image was selected
            {
                //Check for group name. If one exists, set image to first letter.
                if(currentGroup.getGroupName() != null && !currentGroup.getGroupName().isEmpty())
                {
                    ColorGenerator generator = ColorGenerator.MATERIAL;
                    TextDrawable drawable = TextDrawable
                            .builder()
                            .beginConfig()
                            .width(96)
                            .height(96)
                            .endConfig()
                            .buildRound(String.valueOf(currentGroup.getGroupName().charAt(0)), generator.getRandomColor());
                    groupViewHolder.groupPhoto.setImageDrawable(drawable);
                }
                else //If no username or email address, set to default user image
                {
                    groupViewHolder.groupPhoto.setImageResource(R.drawable.ic_user); //Set photo to default image
                }
            }
        }
        else if(viewHolder instanceof LetterViewHolderGroup)
        {
            LetterViewHolderGroup alphabetViewHolderGroup = (LetterViewHolderGroup) viewHolder;

            if(groupList.get(position).getGroupName() != null && !groupList.get(position).getGroupName().isEmpty())
            {
                alphabetViewHolderGroup.letter.setText(groupList.get(position).getGroupName().toUpperCase()); //Name. Later on the first letter of the name will be taken for the header
            }
            else
            {
                alphabetViewHolderGroup.letter.setText("#"); //If name is null, set header to #
            }
        }
    }

    @Override
    public int getItemViewType(int position)
    {
        return groupList.get(position).getViewTypeGroup(); //Used to determine if view selected is group or alphabet character
    }

    @Override
    public int getItemCount() //Returns how many items we want to display in RecycleView
    {
        return groupList.size(); //Display as many items as there are groups
    }

    public Group getGroupAt(int position) //Return group at specified position in list
    {
        return groupList.get(position);
    }

    public void setGroups(List<Group> groups) //Get all groups and pass to local list that is used to display them in RecycleView
    {
        this.groupList = groups;
        this.groupListFull = new ArrayList<>(groups);
        notifyDataSetChanged(); //Tells Adapter to redraw layout (CHANGE LATER ON)
    }

    //Nested Class - Holds Views for RecycleView layout
    class GroupViewHolder extends RecyclerView.ViewHolder
    {
        private TextView groupName;
        private ImageView groupPhoto;

        //Background (Delete animation) and Foreground (group info)
        public RelativeLayout viewBackground;
        public RelativeLayout viewForeground;


        //ItemView represents the card
        public GroupViewHolder(@NonNull View itemView)
        {
            super(itemView);
            //Items inside the card
            groupName = itemView.findViewById(R.id.group_card_name);
            groupPhoto = itemView.findViewById(R.id.group_card_photo);

            //The foreground and background of the card
            viewBackground = itemView.findViewById(R.id.view_background);
            viewForeground = itemView.findViewById(R.id.view_foreground);

            //Carry out instructions when group card in list is clicked
            itemView.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View view)
                {
                    int position = getAdapterPosition(); //Pass position of clicked card

                    //Make sure item with invalid position is not clicked
                    //Possible if deleted item that is in the animation of behind deleted is clicked on
                    if(listener != null && position != RecyclerView.NO_POSITION)
                    {
                        listener.onItemClick(groupList.get(position)); //Get group object that corresponds to card that was clicked
                    }
                }
            });
        }
    }

    public class LetterViewHolderGroup extends RecyclerView.ViewHolder
    {
        TextView letter;
        public LetterViewHolderGroup(@NonNull View itemView)
        {
            super(itemView);
            letter = itemView.findViewById(R.id.letter);
        }
    }


    public interface OnItemClickListener
    {
        void onItemClick(Group group);
    }

    public void setOnItemClickListener(OnItemClickListener listener)
    {
        this.listener = listener;
    }

    @Override
    public Filter getFilter()
    {
        return groupFilter;
    }

    private Filter groupFilter = new Filter()
    {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) //Constraint is input form SearchView field
        {
            List<Group> filteredListGroup = new ArrayList<>(); //Will only contain filtered group items

            if(constraint == null || constraint.length() == 0) //If input field is empty, show all groups
            {
                filteredListGroup.addAll(groupListFull);
            }
            else //If there was something typed into the search field
            {
                String filterPatternGroup = constraint.toString().toLowerCase().trim(); //Takes input, makes it lowercase and removed empty spaces at beginning and end
                for(Group group: groupListFull)
                {
                    if(group.getGroupName().toLowerCase().startsWith(filterPatternGroup))
                    {
                        filteredListGroup.add(group);
                    }
                }
            }
            FilterResults resultsGroup = new FilterResults();
            resultsGroup.values = filteredListGroup;

            return resultsGroup; //Send to publishResults method
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results)
        {
            groupList.clear(); //Remove groups
            groupList.addAll((List) results.values); //Populate with contacts that match user's search input
            notifyDataSetChanged(); //Tell adapter to refresh its list
        }
    };
}
