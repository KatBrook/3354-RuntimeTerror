package com.example.contact;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

import java.util.ArrayList;

@Entity
@TypeConverters({Converters.class})
public class Group
{
    @PrimaryKey(autoGenerate = true)
    private int id;

    private String groupImagePath;
    private String groupName;
    private ArrayList<Contact> groupMembers; //Holds ID(s) of Contact(s) in Group

    private int viewTypeGroup = Common.VIEWTYPE_GROUP; //Have default be contact

    //For creating letters for groups
    @Ignore //Tell Room Database to ignore this constructor
    public Group(String groupName, int viewTypeGroup)
    {
        this.groupName = groupName;
        setViewTypeGroup(viewTypeGroup);
    }
    //For creating groups
    public Group(String groupImagePath, String groupName, ArrayList<Contact> groupMembers)
    {
        this.groupImagePath = groupImagePath;
        this.groupName = groupName;
        this.groupMembers = groupMembers;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public int getId()
    {
        return id;
    }

    public String getGroupImagePath() { return groupImagePath; }

    public String getGroupName()
    {
        return groupName;
    }

    public ArrayList<Contact> getGroupMembers(){return groupMembers; }

    public int getViewTypeGroup()
    {
        return viewTypeGroup;
    }

    public void setViewTypeGroup(int viewTypeGroup) { this.viewTypeGroup = viewTypeGroup; }
}
