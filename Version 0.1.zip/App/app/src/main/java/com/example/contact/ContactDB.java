package com.example.contact;

import androidx.appcompat.app.AppCompatActivity;

import java.util.*;

public abstract class ContactDB  extends AppCompatActivity {
    Map<String, List<String>> contact = new HashMap<String, List<String>>();
    Map<String, List<String>> group = new HashMap<String, List<String>>();

    public void getContactInfo(String contactID){};

    public void setContactInfo(List<String> contactInfo)
    {
        //contact.put(, contactInfo)
    }

    public void updateContactInfo(String contactID, List<String> contactInfo)
    {
        if(contact.containsKey(contactID)) //If Key (Contact) exists
        {
            contact.put(contactID, contactInfo); //Update contact info
        }
    }

    public String createContactKey()
    {
        String key = "";



        return key;
    }


}
