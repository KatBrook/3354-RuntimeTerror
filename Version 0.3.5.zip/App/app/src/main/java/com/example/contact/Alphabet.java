package com.example.contact;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class Alphabet extends AppCompatActivity
{
    RecyclerView recycler_alphabet;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alphabet);

        recycler_alphabet = findViewById(R.id.recycler_alphabet);
        AlphabetAdapter alphabetAdapter = new AlphabetAdapter();

        //Get letter user selected, pass to MainActivity and scroll to that letter in contact list
        alphabetAdapter.setOnAlphabetClickListener(new AlphabetAdapter.OnAlphabetClickListener()
        {
            @Override
            public void onAlphabetClickListener(String alphabet, int position)
            {
                if(position != -1)
                {
                    Intent returnIntent = new Intent();
                    returnIntent.putExtra(Common.LETTER_SELECTED, alphabet);
                    setResult(Activity.RESULT_OK, returnIntent);
                    finish();
                }
            }
        });
        recycler_alphabet.setLayoutManager(new GridLayoutManager(this, 4)); //4 letters per row
        recycler_alphabet.setAdapter(alphabetAdapter);
    }
}
