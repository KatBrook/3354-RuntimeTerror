package com.example.contact;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;


public class ContactPage extends AppCompatActivity {
    private int id;
    private String userName;
    private String imageFilePath;
    private String cellNum;
    private String homeNum;
    private String workNum;
    private String email;
    private String address;
    private TextView primaryText;

    private Button textButton;
    private Button callButton;
    private Button emailButton;

    private Button editButton;
    private Button deleteButton;
    private Button blacklistButton;

    private ContactViewModel contactViewModel;

    public static final int EDIT_CONTACT_REQUEST = 2001;


    //-----------------------------------onCreate-----------------------------------//
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_page);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        createIDs();
        getContactData();
        displayPrimaryInfo();

    }

    private void createIDs()
    {
        //Buttons
        textButton = findViewById(R.id.textButton);
        callButton = findViewById(R.id.callButton);
        emailButton = findViewById(R.id.emailButton);
        editButton = findViewById(R.id.editButton);
        deleteButton = findViewById(R.id.deleteButton);
        blacklistButton = findViewById(R.id.blacklistButton);
        primaryText = findViewById(R.id.primaryText);
    }

    public void getContactData()
    {
        Intent intent = getIntent();
        if(intent != null)
        {
            id = intent.getIntExtra(Common.CONTACT_ID, -1);
            imageFilePath = intent.getStringExtra(Common.CONTACT_PHOTO);
            userName = intent.getStringExtra(Common.CONTACT_USERNAME);
            cellNum = intent.getStringExtra(Common.CONTACT_MOBILE);
            homeNum = intent.getStringExtra(Common.CONTACT_HOME);
            workNum = intent.getStringExtra(Common.CONTACT_WORK);
            email = intent.getStringExtra(Common.CONTACT_EMAIL);
            address = intent.getStringExtra(Common.CONTACT_ADDRESS);
        }
    }

    public void displayPrimaryInfo()
    {
        if(userName != null && !userName.isEmpty())
        {
            primaryText.setText(userName);
        } else if(cellNum != null && !cellNum.isEmpty())
        {
            primaryText.setText(cellNum);
        } else if(homeNum != null && !homeNum.isEmpty())
        {
            primaryText.setText(homeNum);
        } else if(workNum != null && !workNum.isEmpty())
        {
            primaryText.setText(workNum);
        } else if(email != null && !email.isEmpty())
        {
            primaryText.setText(email);
        } else if(address != null && !address.isEmpty())
        {
            primaryText.setText(address);
        }
    }

    public void backButtonPressed(View view)
    {
        Intent openMainActivityIntent = new Intent(this, MainActivity.class);
        startActivity(openMainActivityIntent);
    }

    public void textButtonPressed(View view)
    {

    }

    public void callButtonPressed(View view)
    {

    }

    public void emailButtonPressed(View view)
    {

    }

    public void editButtonPressed(View view)
    {
        Intent intent = new Intent(ContactPage.this, AddEditContact.class);
        intent.putExtra(Common.CONTACT_ID, id); //Pass to AddEditContact to later pass back to MainActivity in order to tell database what contact to update
        intent.putExtra(Common.CONTACT_USERNAME, userName);
        intent.putExtra(Common.CONTACT_PHOTO, imageFilePath);
        intent.putExtra(Common.CONTACT_MOBILE, cellNum);
        intent.putExtra(Common.CONTACT_HOME, homeNum);
        intent.putExtra(Common.CONTACT_WORK, workNum);
        intent.putExtra(Common.CONTACT_EMAIL, email);
        intent.putExtra(Common.CONTACT_ADDRESS, address);
        startActivityForResult(intent, EDIT_CONTACT_REQUEST);
    }

    public void deleteButtonPressed(View view)
    {

    }

    public void blacklistButtonPressed(View view)
    {

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        //If requestCode to edit contact is sent and there is no error
        if(requestCode == EDIT_CONTACT_REQUEST)
        {
            if(resultCode == RESULT_OK)
            {
                int id = data.getIntExtra(Common.CONTACT_ID, -1);

                if(id == -1) //If something went wrong retrieving id
                {
                    Toast.makeText(this, "Error. Changes to contact could not be saved", Toast.LENGTH_SHORT).show();
                    //Return to main activity
                    Intent openMainActivityIntent = new Intent(this, MainActivity.class);
                    startActivity(openMainActivityIntent);
                }

                //Retrieve contact information from AddEditContact page
                String contactPhoto = data.getStringExtra(Common.CONTACT_PHOTO);
                String userName = data.getStringExtra(Common.CONTACT_USERNAME);
                String cellNum = data.getStringExtra(Common.CONTACT_MOBILE);
                String homeNum = data.getStringExtra(Common.CONTACT_HOME);
                String workNum = data.getStringExtra(Common.CONTACT_WORK);
                String email = data.getStringExtra(Common.CONTACT_EMAIL);
                String address = data.getStringExtra(Common.CONTACT_ADDRESS);

                //Add fields to contact object
                Contact contact = new Contact(contactPhoto, userName, cellNum, homeNum, workNum, email, address);
                contact.setId(id); //Pass in primary key so database can identify which contact to update

                contactViewModel = new ViewModelProvider(this).get(ContactViewModel.class);
                contactViewModel.updateContact(contact);

                //Display toast informing user that changes to contact have been saved.
                Toast.makeText(this, "Contact updated", Toast.LENGTH_SHORT).show();

                //Return to main activity
                Intent openMainActivityIntent = new Intent(this, MainActivity.class);
                startActivity(openMainActivityIntent);
            }
            else //If there was an error in editing contact
            {
                //Display toast informing user that changed to contact could not be saved.
                Toast.makeText(this, "Error. Changes to contact could not be saved", Toast.LENGTH_SHORT).show();

                //Return to main activity
                Intent openMainActivityIntent = new Intent(this, MainActivity.class);
                startActivity(openMainActivityIntent);
            }
        }

    }
}
