package com.example.contact;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;

public class MainActivity extends AppCompatActivity
{
    private ContactViewModel contactViewModel;

    private final String[] letters = {"A","B","C","D","E","F","G","H","I","J","K","L","M",
                                    "N","O","P","Q","R","S","T","U","V","W","X","Y","Z","#"};

    private static final int PICK_IMAGE_REQUEST_CODE = 1000;
    private static final int READ_EXTERNAL_STORAGE_REQUEST_CODE = 1001;

    //Request Code
    public static final int ADD_CONTACT_REQUEST = 2000;

    //-----------------------------------OnCreate-----------------------------------//
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FloatingActionButton buttonAddContact = findViewById(R.id.addButton);
        buttonAddContact.setOnClickListener(new View.OnClickListener() //Called when button is pressed
        {
            @Override
            public void onClick(View view) //When button is pressed, open AddEditContact activity and get data inputted
            {
                Intent intent = new Intent(MainActivity.this, AddEditContact.class);
                startActivityForResult(intent, ADD_CONTACT_REQUEST);
            }
        });

        //Set up RecycleView
        RecyclerView recyclerView = findViewById(R.id.contact_list);
        recyclerView.setLayoutManager(new LinearLayoutManager(this)); //Every RecyclerView needs a layout manager
        recyclerView.setHasFixedSize(true);

        final ContactAdapter adapter = new ContactAdapter();
        recyclerView.setAdapter(adapter); //Populate RecyclerView with list of contacts in adapter

        //Gain access to ContactViewModel
        contactViewModel = new ViewModelProvider(this).get(ContactViewModel.class);
        //If activity is in foreground and list of contacts have changed, update RecyclerView
        contactViewModel.getAllContacts().observe(this, new Observer<List<Contact>>()
        {
            @Override
            public void onChanged(List<Contact> contacts)
            {
                //Updates RecyclerView whenever there is a change in the list of contacts
                adapter.setContacts(contacts);
            }
        });

        adapter.setOnItemClickListener(new ContactAdapter.OnItemClickListener()
        {
            @Override
            public void onItemClick(Contact contact)
            {
                //Open Contact Page Activity (where contact can be edited or deleted)
                Intent intent = new Intent(MainActivity.this, AddEditContact.class); //Will change to Tiffany's class which will have option to add or edit. Right now this just goes straight to edit
                //WATCH END OF VIDEO 7
            }
        });



        displayInformation();
    }

    //-----------------------------------Display-----------------------------------//
    private void displayInformation()
    {
        //Displays user information
        displayUserInfo();
        //Displays contacts in alphabetical order, sorted by first letter of username
        displayContactList();
    }

    private void displayUserInfo()
    {
        //Display user photo and name
        TextView user = findViewById(R.id.userName);
        user.setText("John Doe");
    }

    private void displayContactList()
    {
        LinearLayout contactsLayout = findViewById(R.id.contactLayout);

        for(int i = 0; i < letterTextViews().size(); i++)
        {
            contactsLayout.addView(letterTextViews().get(i));
        }
    }

    //-----------------------------------Listeners-----------------------------------//

    //When user clicks on image for user, allow them to upload picture form phone
    public void userPhotoClicked(View view)
    {
        imagePicker();
    }

    //-----------------------------------Functionality Implementations-----------------------------------//
    private List<TextView> letterTextViews()
    {
        List<TextView> lettersArray = new ArrayList<TextView>();

        //Go through letters
        for(int letter = 0; letter < letters.length; letter++) //Cycle through letters
        {
            //Create a TextViewContext
            TextView textView = new TextView(getApplication()); //Create textView instance

            //Create the layout for the TextView
            RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(
                    RelativeLayout.LayoutParams.MATCH_PARENT, //Width
                    RelativeLayout.LayoutParams.WRAP_CONTENT //Height
            );

            //Add the layout properties to the TextView
            textView.setLayoutParams(lp);
            textView.setPadding(5,5,5,5);

            //Set the text of the TextView equal to the letter
            textView.setText(letters[letter]);
            lettersArray.add(textView);
        }
        return lettersArray;
    }

    private void imagePicker()
    {
        if(ActivityCompat.checkSelfPermission(this, READ_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED)
        {
            //Step 1: Create Intent
            // (ACTION_GET_CONTENT allows user to select particular kind of data and return it)
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);

            //Step 2: Set intent type
            // (This indicates the type of data the intent wants returned to it)
            intent.setType("image/*");

            //Extras (Elaborate on what this does)
            intent.putExtra("crop", "true");
            intent.putExtra("scale", true);
            intent.putExtra("aspectX", 16);
            intent.putExtra("aspectY", 9);

            //Step 4: Call startActivityForResult method
            // (Starts another activity and receives a result back from it)
            startActivityForResult(intent, PICK_IMAGE_REQUEST_CODE);
        }
        else
        {
            String permissions[] = {READ_EXTERNAL_STORAGE};
            ActivityCompat.requestPermissions(this, permissions, READ_EXTERNAL_STORAGE_REQUEST_CODE);
        }
    }

    //-----------------------------------Permissions-----------------------------------//
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        //Implements functionality for when request codes are sent

        //If requestCode to select picture is sent and there is no error
        if(requestCode == PICK_IMAGE_REQUEST_CODE && resultCode == RESULT_OK)
        {
            //Get Uri of selected image and set user photo to it
            Uri uri = data.getData();
            if(uri != null)
            {
                ImageView userPhoto = findViewById(R.id.userPhoto);
                userPhoto.setImageURI(uri);
            }
        }

        //If requestCode to add contact is sent and there is no error
        if(requestCode == ADD_CONTACT_REQUEST && resultCode == RESULT_OK)
        {
            //Retrieve contact information from AddEditContact page
            String contactPhoto = data.getStringExtra(AddEditContact.CONTACT_PHOTO);
            String userName = data.getStringExtra(AddEditContact.CONTACT_USERNAME);
            String cellNum = data.getStringExtra(AddEditContact.CONTACT_MOBILE);
            String homeNum = data.getStringExtra(AddEditContact.CONTACT_HOME);
            String workNum = data.getStringExtra(AddEditContact.CONTACT_WORK);
            String email = data.getStringExtra(AddEditContact.CONTACT_EMAIL);
            String address = data.getStringExtra(AddEditContact.CONTACT_ADDRESS);

            //Add fields to contact object
            Contact contact = new Contact(contactPhoto, userName, cellNum, homeNum, workNum, email, address);
            //Add contact object to database
            contactViewModel.insertContact(contact);
            //Display toast informing user that contact was added.
            Toast.makeText(this, "Contact added", Toast.LENGTH_SHORT).show();
        }
        else //If there was error in adding contact
        {
            //Display toast informing user that contact was not added.
            Toast.makeText(this, "Error. Contact not added", Toast.LENGTH_SHORT).show();
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults)
    {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if(requestCode == READ_EXTERNAL_STORAGE_REQUEST_CODE)
        {
            //If the user allows permission
            if(grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                imagePicker();
            }
        }
    }
}
