package com.example.contact;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;

import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;


public class AddEditContact extends AppCompatActivity {
    private String intent;

    private EditText userName;
    private ImageView contactPhoto;
    private EditText cellNum;
    private EditText homeNum;
    private EditText workNum;
    private EditText email;
    private EditText address;

    private Button saveButton;

    private String selectedImageUri;

    private static final int PICK_IMAGE_REQUEST_CODE = 1000;
    private static final int READ_EXTERNAL_STORAGE_REQUEST_CODE = 1001;

    //Key to send back contact information
    public static final String CONTACT_USERNAME = "com.example.contact.CONTACT_USERNAME";
    public static final String CONTACT_PHOTO = "com.example.contact.CONTACT_PHOTO";
    public static final String CONTACT_MOBILE = "com.example.contact.CONTACT_MOBILE";
    public static final String CONTACT_HOME = "com.example.contact.CONTACT_HOME";
    public static final String CONTACT_WORK = "com.example.contact.CONTACT_WORK";
    public static final String CONTACT_EMAIL = "com.example.contact.CONTACT_EMAIL";
    public static final String CONTACT_ADDRESS = "com.example.contact.CONTACT_ADDRESS";

    //-----------------------------------onCreate-----------------------------------//
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_contact);
        //Have layout move up when keyboard appears
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        //Determine intent
        determineIntent(); //Was activity opened to add or to edit a contact?
        //Set Toolbar title
        setToolBarTitle();
        //Get IDs and assign to variables
        createIDs();
        //Disable save button at start up (as no values have been entered)
        checkForValues();
        //Add listeners for EditText fields
        addListeners();
    }
    private void determineIntent()
    {
        //Determine if the contact information activity was opened with the intention of adding or editing a contact
        Bundle extras = getIntent().getExtras();
        if(extras != null)
        {
            intent = extras.getString("AddOrEdit");
        }
        else //If contact info activity was somehow accessed without specification of what it is to be used for
        {
            intent = "Unknown";
        }
    }

    //-----------------------------------Set Toolbar Title-----------------------------------//
    private void setToolBarTitle()
    {
        Toolbar contact_info_toolbar = findViewById(R.id.contact_info_toolbar);
        if(intent.equals("Add"))
        {
            contact_info_toolbar.setTitle("Create Contact");
        }
        else if(intent.equals("Edit"))
        {
            contact_info_toolbar.setTitle("Edit Contact");
        }
    }
    //-----------------------------------EditText IDs-----------------------------------//
    private void createIDs()
    {
        saveButton = findViewById(R.id.saveButton);
        //Contact information
        userName = findViewById(R.id.userNameInput);
        cellNum = findViewById(R.id.mobileNumInput);
        homeNum = findViewById(R.id.homeNumInput);
        workNum = findViewById(R.id.workNumInput);
        email = findViewById(R.id.emailInput);
        address = findViewById(R.id.addressInput);
    }

    //-----------------------------------Listeners-----------------------------------//
    public void contactPhotoClicked(View view)
    {
        pickImage();
    }

    //If "cancel" button is pressed, return to main activity
    public void cancelButtonPressed(View view)
    {
        Intent openMainActivityIntent = new Intent(this, MainActivity.class);
        startActivity(openMainActivityIntent);
    }

    //When save button is pressed, save contact info
    public void saveButtonPressed(View view)
    {
        //Return to main activity with contact fields
        Intent data = new Intent();
        data.putExtra(CONTACT_USERNAME, userName.getText().toString());
        data.putExtra(CONTACT_PHOTO, selectedImageUri);
        data.putExtra(CONTACT_MOBILE, cellNum.getText().toString());
        data.putExtra(CONTACT_HOME, homeNum.getText().toString());
        data.putExtra(CONTACT_WORK, workNum.getText().toString());
        data.putExtra(CONTACT_EMAIL, email.getText().toString());
        data.putExtra(CONTACT_ADDRESS, address.getText().toString());

        //Result code specifies whether input was successful or not
        setResult(RESULT_OK, data);
        finish();
    }

    //-----------------------------------TextWatcher-----------------------------------//
    private void addListeners()
    {
        //set Listener for EditText fields
        userName.addTextChangedListener(watcher);
        cellNum.addTextChangedListener(watcher);
        homeNum.addTextChangedListener(watcher);
        workNum.addTextChangedListener(watcher);
        email.addTextChangedListener(watcher);
        address.addTextChangedListener(watcher);
    }

    private TextWatcher watcher = new TextWatcher()
    {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) { }
        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3)
        {
            //Check if any values have been entered for any field
            checkForValues();
        }
        @Override
        public void afterTextChanged(Editable editable) { }
    };

    //Check if any field was filled out with a value
    private void checkForValues()
    {
        //If no values have been entered
        if(!userName.getText().toString().isEmpty()
                || !cellNum.getText().toString().isEmpty()
                || !homeNum.getText().toString().isEmpty()
                || !workNum.getText().toString().isEmpty()
                || !email.getText().toString().isEmpty()
                || !address.getText().toString().isEmpty())
        {
            saveButton.setEnabled(true); //Enable save button
        }
        else //If values have been entered
        {
            saveButton.setEnabled(false); //Disable save button
        }
    }

    //-----------------------------------Implementation-----------------------------------//
    private void pickImage()
    {
        if(ActivityCompat.checkSelfPermission(this, READ_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED)
        {
            //Step 1: Create Intent
            // (ACTION_GET_CONTENT allows user to select particular kind of data and return it)
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);

            //Step 2: Set intent type
            // (This indicates the type of data the intent wants returned to it)
            intent.setType("image/*");

            //Extras (Elaborate on what this does)
            intent.putExtra("crop", "true");
            intent.putExtra("scale", true);
            intent.putExtra("aspectX", 16);
            intent.putExtra("aspectY", 9);

            //Step 4: Call startActivityForResult method
            // (Starts another activity and receives a result back from it)
            startActivityForResult(intent, PICK_IMAGE_REQUEST_CODE);
        }
        else
        {
            String permissions[] = {READ_EXTERNAL_STORAGE};
            ActivityCompat.requestPermissions(this, permissions, READ_EXTERNAL_STORAGE_REQUEST_CODE);
        }
    }

    //-----------------------------------Permissions-----------------------------------//
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        //Implements functionality for when PICK_IMAGE_REQUEST_CODE is sent

        //If startActivityForResult starts with no errors
        if(requestCode == PICK_IMAGE_REQUEST_CODE && resultCode == RESULT_OK)
        {
            if(data.getData() != null)
            {
                contactPhoto = findViewById(R.id.contactPhoto);
                contactPhoto.setImageURI(data.getData());

                //Save Uri to image
                selectedImageUri = data.getData().toString();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults)
    {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if(requestCode == READ_EXTERNAL_STORAGE_REQUEST_CODE)
        {
            //If the user allows permission
            if(grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                pickImage();
            }
        }
    }
}
