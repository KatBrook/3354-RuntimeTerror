package com.example.contact;

import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

/*
Allows you to enter list of Contacts into RecycleView
ContactAdapter.contactHolder is passed in so the RecyclerView Adapter knows this is the view holder we want to use
 */
public class ContactAdapter extends RecyclerView.Adapter<ContactAdapter.ContactHolder>
{
    private List<Contact> contacts = new ArrayList<>();
    private OnItemClickListener listener;

    @NonNull
    @Override //Where you create and return a contact holder
    public ContactHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        //Parent is the ViewGroup parameter in the method. This is the RecyclerView
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.contact_item, parent, false);
        return new ContactHolder(itemView);
    }

    @Override //This is where we pull data from each Contact object and put it into the views of the ContactHolder
    public void onBindViewHolder(@NonNull ContactHolder holder, int position)
    {
        Contact currentContact = contacts.get(position);

        //Set card name equal to contact name
        if(currentContact.getName() != null) //If name was entered for contact
        {
            holder.contactName.setText(currentContact.getName()); //Set name equal to contact name
        }
        else //If no name was entered for contact
        {
            holder.contactName.setText("Unknown Name");
        }

        //Set card number equal to number entered
        if(currentContact.getMobileNumber() != null) //If mobile number was entered for contact
        {
            holder.contactNumber.setText(currentContact.getMobileNumber()); //Set number equal to mobile
        }
        else if(currentContact.getHomeNumber() != null) //If mobile number is null but home number was entered for contact
        {
            holder.contactNumber.setText(currentContact.getHomeNumber()); //Set number equal to home
        }
        else if(currentContact.getWorkNumber() != null) //If mobile and home number is null but work number was entered for contact
        {
            holder.contactNumber.setText(currentContact.getWorkNumber()); //Set number equal to work
        }
        else //If no number was entered for mobile nor home nor work
        {
            holder.contactNumber.setText("Unknown Number");
        }

        //Set card photo equal to contact photo
        if(currentContact.getContactImageUri() != null) //If image was selected for contact
        {
            holder.contactPhoto.setImageURI(Uri.parse(currentContact.getContactImageUri())); //Set photo to selected image
        }
        else //If no image was selected
        {
            holder.contactPhoto.setImageResource(R.drawable.ic_user); //Set photo to default image
        }
    }

    @Override
    public int getItemCount() //Returns how many items we want to display in RecycleView
    {
        return contacts.size(); //Display as many items as there are contacts
    }

    public void setContacts(List<Contact> contacts) //Get all Contacts and pass to local list that is used to display them in RecycleView
    {
        this.contacts = contacts;
        notifyDataSetChanged(); //Tells Adapter to redraw layout (CHANGE LATER ON)
    }

    //Nested Class - Holds Views for RecycleView layout
    class ContactHolder extends RecyclerView.ViewHolder
    {
        private TextView contactName;
        private TextView contactNumber;
        private ImageView contactPhoto;

        //ItemView represents the card
        public ContactHolder(@NonNull View itemView)
        {
            super(itemView);
            //Items inside the card
            contactName = itemView.findViewById(R.id.contact_card_name);
            contactNumber = itemView.findViewById(R.id.contact_card_number);
            contactPhoto = itemView.findViewById(R.id.contact_card_photo);

            //Carry out instructions when contact card in list is clicked
            itemView.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View view)
                {
                    int position = getAdapterPosition(); //Pass position of clicked card

                    //Make sure item with invalid position is not clicked
                    //Possible if deleted item that is in the animation of beind deleted is clicked on
                    if(listener != null && position != RecyclerView.NO_POSITION)
                    {
                        listener.onItemClick(contacts.get(position)); //Get contact object that corresponds to card that was clicked
                    }
                }
            });
        }
    }


    public interface OnItemClickListener
    {
        void onItemClick(Contact contact);
    }

    public void setOnItemClickListener(OnItemClickListener listener)
    {
        this.listener = listener;
    }
}
