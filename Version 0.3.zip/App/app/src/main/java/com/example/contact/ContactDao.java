package com.example.contact;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Ignore;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;


/*
Room provides an abstraction layer over SQLite to allow fluent database access
SQLite is a local database that doesn't require internet access.
It saves its data into a text file and it's saved locally on the device
Android comes with SQLite database implementation built in

@Dao defines ContactDao interface as a data access object.
*/


@Dao
public interface ContactDao
{
    //Use for displaying contacts on contact list activity
    @Query("select * from contact") //SQL Statement
    List<Contact> loadAllContacts(); //Method carries out SQL Statement

    //Implement ability to handle situation of duplicates
    @Insert
    void insertContact(Contact contact);

    @Delete
    void deleteContact(Contact contact);
}
