package com.example.contact;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;


import static android.Manifest.permission.READ_EXTERNAL_STORAGE;


public class ContactInfoPage extends AppCompatActivity {
    private EditText userNameInput;
    private ImageView contactPhoto;
    private EditText cellNumInput;
    private EditText homeNumInput;
    private EditText workNumInput;
    private EditText emailInput;
    private EditText addressInput;

    private Button saveButton;

    private Uri selectedImageUri = null;

    private static final int PICK_IMAGE_REQUEST_CODE = 1000;
    private static final int READ_EXTERNAL_STORAGE_REQUEST_CODE = 1001;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_info_page);
        //Have layout move up when keyboard appears
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

        saveButton = findViewById(R.id.saveButton);

        //Contact information
        userNameInput = findViewById(R.id.userNameInput);
        cellNumInput = findViewById(R.id.mobileNumInput);
        homeNumInput = findViewById(R.id.homeNumInput);
        workNumInput = findViewById(R.id.workNumInput);
        emailInput = findViewById(R.id.emailInput);
        addressInput = findViewById(R.id.addressInput);

        //Disable save button at start up (as no values have been entered)
        checkForValues();

        //set Listener for EditText fields
        userNameInput.addTextChangedListener(watcher);
        cellNumInput.addTextChangedListener(watcher);
        homeNumInput.addTextChangedListener(watcher);
        workNumInput.addTextChangedListener(watcher);
        emailInput.addTextChangedListener(watcher);
        addressInput.addTextChangedListener(watcher);


    }

    //TextWatcher for save button
    private TextWatcher watcher = new TextWatcher()
    {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) { }
        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3)
        {
            //Check if any values have been entered for any field
            checkForValues();
        }
        @Override
        public void afterTextChanged(Editable editable) { }
    };

    //Check if any field was filled out with a value
    private void checkForValues()
    {

        //If no values have been entered
        if(!userNameInput.getText().toString().isEmpty()
            || !cellNumInput.getText().toString().isEmpty()
            || !homeNumInput.getText().toString().isEmpty()
            || !workNumInput.getText().toString().isEmpty()
            || !emailInput.getText().toString().isEmpty()
            || !addressInput.getText().toString().isEmpty())
        {
            saveButton.setEnabled(true); //Enable save button
        }
        else //If values have been entered
        {
            saveButton.setEnabled(false); //Disable save button
        }
    }

    //Called when save button is pressed
    public Contact contactInformation()
    {
        //Create instantiation of Contact Class
        Contact contact = new Contact();

        //Contact Name
        String userName = userNameInput.getText().toString();
        contact.setName(userName);

        //Contact Photo
        contact.setContactImageUri(selectedImageUri.toString());

        //Contact Cell Number
        String cellNum = cellNumInput.getText().toString();
        contact.setMobileNumber(cellNum);

        //Contact Home Number
        String homeNum = homeNumInput.getText().toString();
        contact.setHomeNumber(homeNum);

        //Contact Work Number
        String workNum = workNumInput.getText().toString();
        contact.setWorkNumber(workNum);

        //Contact Email
        String email = emailInput.getText().toString();
        contact.setEmailAddress(email);

        //Contact Address
        String address = addressInput.getText().toString();
        contact.setAddress(address);

        return contact;
    }

    //If user taps on contact photo, allow user to upload picture from gallery
    public void contactPhotoClicked(View view)
    {
        pickImage();
    }

    private void pickImage()
    {
        if(ActivityCompat.checkSelfPermission(this, READ_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED)
        {
            //Step 1: Create Intent
            // (ACTION_GET_CONTENT allows user to select particular kind of data and return it)
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);

            //Step 2: Set intent type
            // (This indicates the type of data the intent wants returned to it)
            intent.setType("image/*");

            //Extras (Elaborate on what this does)
            intent.putExtra("crop", "true");
            intent.putExtra("scale", true);
            intent.putExtra("aspectX", 16);
            intent.putExtra("aspectY", 9);

            //Step 4: Call startActivityForResult method
            // (Starts another activity and receives a result back from it)
            startActivityForResult(intent, PICK_IMAGE_REQUEST_CODE);
        }
        else
        {
            String permissions[] = {READ_EXTERNAL_STORAGE};
            ActivityCompat.requestPermissions(this, permissions, READ_EXTERNAL_STORAGE_REQUEST_CODE);
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        //Implements functionality for when PICK_IMAGE_REQUEST_CODE is sent

        //If startActivityForResult starts with no errors
        if(requestCode == PICK_IMAGE_REQUEST_CODE)
        {
            //If there is error
            if(resultCode != RESULT_OK)
            {
                return;
            }

            if(data.getData() != null)
            {
                contactPhoto = findViewById(R.id.contactPhoto);
                contactPhoto.setImageURI(data.getData());

                //Save Uri to image
                selectedImageUri = data.getData();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults)
    {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if(requestCode == READ_EXTERNAL_STORAGE_REQUEST_CODE)
        {
            //If the user allows permission
            if(grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                pickImage();
            }
        }
    }



    //If "cancel" button is pressed, return to main activity
    public void cancelButtonPressed(View view)
    {
        Intent openMainActivityIntent = new Intent(this, MainActivity.class);
        startActivity(openMainActivityIntent);
    }

    //When save button is pressed, save contact info
    public void saveButtonPressed(View view)
    {
        /*
            -Room database SHOULD NEVER be accessed in main thread, use worker thread to access
            -Accessing in main thread can lead to lag in UI while it waits for information to be pulled.
            -Having a worker thread access information can have UI continue uninterrupted while information is pulled
            in the background.
        */
        AsyncTask.execute(new Runnable()
        {
            @Override
            public void run()
            {
                //Determine if the contact information activity was opened with the intention of adding or editing a contact
                Bundle extras = getIntent().getExtras();
                String editOrAdd;
                if(extras != null)
                {
                    editOrAdd = (String) extras.get("AddOrEdit");
                }
                else //If contact info activity was somehow accessed without specification of what it is to be used for
                {
                    editOrAdd = "Error";
                }

                //If user wishes to add contact
                if(editOrAdd == "Add")
                {
                    //Add contact into database
                    ContactDB.getContactDB(getApplicationContext()).contactDao().insertContact(contactInformation());
                }
                //If user wishes to edit contact
                else if(editOrAdd == "Edit")
                {
                    //Update existing contact in database
                }
            }
        });
    }

}
