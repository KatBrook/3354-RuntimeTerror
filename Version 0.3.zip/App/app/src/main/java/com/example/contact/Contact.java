package com.example.contact;

import android.graphics.Bitmap;
import android.net.Uri;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Contact
{
    private @PrimaryKey @NonNull String id;

    private String contactImageUri;
    private String name;
    private String mobileNumber;
    private String homeNumber;
    private String workNumber;
    private String emailAddress;
    private String address;

    @NonNull
    public String getId()
    {
        return id;
    }
    @NonNull
    public void setId(String id)
    {
        this.id = id;
    }

    public String getContactImageUri()
    {
        return contactImageUri;
    }

    public void setContactImageUri(String contactImageUri) {

        this.contactImageUri = contactImageUri;
    }
    public String getName()
    {
        return name;
    }
    public void setName(String name)
    {
        this.name = name;
        setId(this.name); //Create ID based on name
    }

    public String getMobileNumber()
    {
        return mobileNumber;
    }
    public void setMobileNumber(String mobileNumber)
    {
        this.mobileNumber = mobileNumber;
    }
    public String getHomeNumber()
    {
        return homeNumber;
    }
    public void setHomeNumber(String homeNumber)
    {
        this.homeNumber = homeNumber;
    }
    public String getWorkNumber()
    {
        return workNumber;
    }
    public void setWorkNumber(String workNumber)
    {
        this.workNumber = workNumber;
    }

    public String getEmailAddress()
    {
        return emailAddress;
    }
    public void setEmailAddress(String emailAddress)
    {
        this.emailAddress = emailAddress;
    }
    public String getAddress()
    {
        return address;
    }
    public void setAddress(String address)
    {
        this.address = address;
    }
}
