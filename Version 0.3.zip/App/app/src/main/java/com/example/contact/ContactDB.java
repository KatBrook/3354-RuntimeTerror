package com.example.contact;
import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

/*
Contains the database holder and serves as the main access point for the underlying connection
to your app's persisted relational data.

Class should be abstract and extend RoomDatabase, it should include the list of entities
associated with the database, and it should contain an abstract method that returns the class
that is associated with @Dao
 */

@Database(entities = {Contact.class, Group.class}, version = 1)
public abstract class ContactDB extends RoomDatabase
{
    private static final String DB_NAME = "contact-db";
    private static ContactDB INSTANCE;

    public abstract ContactDao contactDao();
    public abstract GroupDao groupDao();

    public static ContactDB getContactDB(Context context)
    {
        if(INSTANCE == null)
        {
            //Build database if instantiation does not exist
            Room.databaseBuilder(context.getApplicationContext(), ContactDB.class, DB_NAME).build();
        }
        return INSTANCE;
    }

    public static void destroyInstance()
    {
        INSTANCE =  null;
    }
}


