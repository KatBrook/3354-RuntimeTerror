package com.example.contact;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;

public class MainActivity extends AppCompatActivity{
    private final String[] letters = {"A","B","C","D","E","F","G","H","I","J","K","L","M",
                                    "N","O","P","Q","R","S","T","U","V","W","X","Y","Z","#"};

    private static final int PICK_IMAGE_REQUEST_CODE = 1000;
    private static final int READ_EXTERNAL_STORAGE_REQUEST_CODE = 1001;


    //Sets the layout
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Displays user information
        displayUserInfo();
        //Displays contacts in alphabetical order, sorted by first letter of username
        displayContactList();
    }

    public void displayUserInfo()
    {
        //------------------User Photo and Name------------------

        TextView user = findViewById(R.id.userName);
        user.setText("John Doe");
    }

    public List<TextView> letters()
    {
        List<TextView> lettersArray = new ArrayList<TextView>();

        //Go through letters
        for(int letter = 0; letter < letters.length; letter++) //Cycle through letters
        {
            //Create a TextViewContext
            TextView textView = new TextView(getApplication()); //Create textView instance

            //Create the layout for the TextView
            RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(
                    RelativeLayout.LayoutParams.MATCH_PARENT, //Width
                    RelativeLayout.LayoutParams.WRAP_CONTENT //Height
            );

            //Add the layout properties to the TextView
            textView.setLayoutParams(lp);
            textView.setPadding(5,5,5,5);

            //Set the text of the TextView equal to the letter
            textView.setText(letters[letter]);
            lettersArray.add(textView);
        }
        return lettersArray;
    }


    public void displayContactList()
    {
        LinearLayout contactsLayout = findViewById(R.id.contactLayout);

        for(int i = 0; i < letters().size(); i++)
        {
            contactsLayout.addView(letters().get(i));
        }
    }

    //When user clicks on image for user, allow them to upload picture form phone
    public void userPhotoClicked(View view)
    {
        pickImage();
    }

    private void pickImage()
    {
        if(ActivityCompat.checkSelfPermission(this, READ_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED)
        {
            //Step 1: Create Intent
            // (ACTION_GET_CONTENT allows user to select particular kind of data and return it)
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);

            //Step 2: Set intent type
            // (This indicates the type of data the intent wants returned to it)
            intent.setType("image/*");

            //Extras (Elaborate on what this does)
            intent.putExtra("crop", "true");
            intent.putExtra("scale", true);
            intent.putExtra("aspectX", 16);
            intent.putExtra("aspectY", 9);

            //Step 4: Call startActivityForResult method
            // (Starts another activity and receives a result back from it)
            startActivityForResult(intent, PICK_IMAGE_REQUEST_CODE);
        }
        else
        {
            String permissions[] = {READ_EXTERNAL_STORAGE};
            ActivityCompat.requestPermissions(this, permissions, READ_EXTERNAL_STORAGE_REQUEST_CODE);
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        //Implements functionality for when PICK_IMAGE_REQUEST_CODE is sent

        //If startActivityForResult starts with no errors
        if(requestCode == PICK_IMAGE_REQUEST_CODE)
        {
            //If there is error
            if(resultCode != RESULT_OK)
            {
                return;
            }
            Uri uri = data.getData();
            if(uri != null)
            {
                ImageView userPhoto = findViewById(R.id.userPhoto);
                userPhoto.setImageURI(uri);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults)
    {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if(requestCode == READ_EXTERNAL_STORAGE_REQUEST_CODE)
        {
            //If the user allows permission
            if(grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                pickImage();
            }
        }
    }
    //Open Contact Page to add Contact Information
    public void addButtonClicked(View view)
    {
        Intent openContactPageAdd = new Intent(this, ContactInfoPage.class);
        openContactPageAdd.putExtra("AddOrEdit", "Add");
        startActivity(openContactPageAdd);
    }
}
