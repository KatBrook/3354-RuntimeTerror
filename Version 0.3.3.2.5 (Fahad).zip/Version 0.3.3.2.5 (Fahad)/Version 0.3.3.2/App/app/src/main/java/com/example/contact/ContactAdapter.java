package com.example.contact;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/*
Allows you to enter list of Contacts into RecycleView
ContactAdapter.contactHolder is passed in so the RecyclerView Adapter knows this is the view holder we want to use
 */
public class ContactAdapter extends RecyclerView.Adapter<ContactAdapter.ContactHolder>
{
    private List<Contact> contacts = new ArrayList<>();
    private List<Contact> contactsCopy = new ArrayList<>();
    private OnItemClickListener listener;

    @NonNull
    @Override //Where you create and return a contact holder
    public ContactHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        //Parent is the ViewGroup parameter in the method. This is the RecyclerView
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.contact_item, parent, false);
        if (contactsCopy.size() == 0)
            contactsCopy.addAll(contacts);
        return new ContactHolder(itemView);
    }

    @Override //This is where we pull data from each Contact object and put it into the views of the ContactHolder
    public void onBindViewHolder(@NonNull ContactHolder holder, int position)
    {
        Contact currentContact = contacts.get(position);

        //Set card name equal to contact name
        if(currentContact.getName() != null && !currentContact.getName().isEmpty()) //If name was entered for contact
        {
            holder.contactName.setText(currentContact.getName()); //Set name equal to contact name
        }
        else //If no name was entered for contact
        {
            holder.contactName.setText("No Name");
        }

        //Set card number equal to number entered
        if(currentContact.getMobileNumber() != null && !currentContact.getMobileNumber().isEmpty()) //If mobile number was entered for contact
        {
            holder.contactNumber.setText(currentContact.getMobileNumber()); //Set number equal to mobile
        }
        else if(currentContact.getHomeNumber() != null && !currentContact.getHomeNumber().isEmpty()) //If mobile number is null but home number was entered for contact
        {
            holder.contactNumber.setText(currentContact.getHomeNumber()); //Set number equal to home
        }
        else if(currentContact.getWorkNumber() != null && !currentContact.getWorkNumber().isEmpty()) //If mobile and home number is null but work number was entered for contact
        {
            holder.contactNumber.setText(currentContact.getWorkNumber()); //Set number equal to work
        }
        else //If no number was entered for mobile nor home nor work
        {
            holder.contactNumber.setText("No Number");
        }

        //Set card photo equal to contact photo
        if(currentContact.getContactImagePath() != null && !currentContact.getContactImagePath().isEmpty()) //If image was selected for contact
        {
            try //If there is no error in getting file, convert to bitmap and set ImageViewer to display it
            {
                Bitmap selectedImage = BitmapFactory.decodeStream(new FileInputStream(new File(currentContact.getContactImagePath())));
                holder.contactPhoto.setImageBitmap(selectedImage); //Set photo to selected image
            }
            catch(FileNotFoundException e) //If there is an error in displaying file, set photo to default image
            {
                e.printStackTrace();
                holder.contactPhoto.setImageResource(R.drawable.ic_user); //Set photo to default image
            }
        }
        else //If no image was selected
        {
            holder.contactPhoto.setImageResource(R.drawable.ic_user); //Set photo to default image
        }
    }

    @Override
    public int getItemCount() //Returns how many items we want to display in RecycleView
    {
        return contacts.size(); //Display as many items as there are contacts
    }

    public Contact getContactAt(int position) //Return contact at specified position in list
    {
        return contacts.get(position);
    }

    public void setContacts(List<Contact> contacts) //Get all Contacts and pass to local list that is used to display them in RecycleView
    {
        this.contacts = contacts;
        notifyDataSetChanged(); //Tells Adapter to redraw layout (CHANGE LATER ON)
    }

    //Nested Class - Holds Views for RecycleView layout
    class ContactHolder extends RecyclerView.ViewHolder
    {
        private TextView contactName;
        private TextView contactNumber;
        private ImageView contactPhoto;

        //Background (Delete animation) and Foreground (Contact info)
        public RelativeLayout viewBackground;
        public RelativeLayout viewForeground;


        //ItemView represents the card
        public ContactHolder(@NonNull View itemView)
        {
            super(itemView);
            //Items inside the card
            contactName = itemView.findViewById(R.id.contact_card_name);
            contactNumber = itemView.findViewById(R.id.contact_card_number);
            contactPhoto = itemView.findViewById(R.id.contact_card_photo);

            //The foreground and background of the card
            viewBackground = itemView.findViewById(R.id.view_background);
            viewForeground = itemView.findViewById(R.id.view_foreground);

            //Carry out instructions when contact card in list is clicked
            itemView.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View view)
                {
                    int position = getAdapterPosition(); //Pass position of clicked card

                    //Make sure item with invalid position is not clicked
                    //Possible if deleted item that is in the animation of behind deleted is clicked on
                    if(listener != null && position != RecyclerView.NO_POSITION)
                    {
                        listener.onItemClick(contacts.get(position)); //Get contact object that corresponds to card that was clicked
                    }
                }
            });
        }
    }


    public void filter(String text) {
        contacts.clear();
        if(text.isEmpty()){
            contacts.addAll(contactsCopy);
        } else{
            text = text.toLowerCase();
            for(Contact item: contactsCopy){
                if(item.getName().toLowerCase().contains(text) || item.getMobileNumber().toLowerCase().contains(text)){
                    contacts.add(item);
                }
            }
        }
        notifyDataSetChanged();
    }


    public interface OnItemClickListener
    {
        void onItemClick(Contact contact);
    }

    public void setOnItemClickListener(OnItemClickListener listener)
    {
        this.listener = listener;
    }
}
