package com.example.contact;

public class Group
{

}
