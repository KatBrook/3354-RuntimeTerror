package com.example.contact;

import java.util.HashMap;
import java.util.Map;

public class ContactDB {
    private static final ContactDB ourInstance = new ContactDB();

    //Stores Contact ID and Information tied to ID
    private Map<String, Contact> contact = new HashMap<String, Contact>();
    //Stores Group ID and Information tied to ID
    private Map<String, Group> group = new HashMap<String, Group>();

    public static ContactDB getInstance() {
        return ourInstance;
    }

    private ContactDB() {
    }

    //Returns Contact Information tied to ID
    public Contact getContactInfo(String userName) //GET
    {
        //Pass in contact ID (based on userName) and return information tied to ID
        return contact.get(contactKey(userName));
    }

    //Creates new ID, tie Contact Information to ID, store in Contact Dictionary
    public void addContactInfo(Contact contactInfo) //ADD
    {
        contact.put(contactKey(contactInfo.getName()), contactInfo);
    }

    //Modify existing contact information
    public void updateContactInfo(String userName, Contact contactInfo) //EDIT
    {
        if(contact.containsKey(contactKey(userName))) //If Key (Contact) exists
        {
            contact.put(contactKey(userName), contactInfo); //Update contact info
        }
    }

    public void deleteContactInfo(String userName) //DELETE
    {
        if(contact.containsKey(contactKey(userName)))
        {
            contact.remove(contactKey(userName));
        }
    }

    //Create and Return Key for Contact
    private String contactKey(String userName)
    {
        //Create key from name (Convert name to base 32 and store number as String)
        String key = Integer.toString(Integer.parseInt(userName, 32));

        return key;
    }
}
