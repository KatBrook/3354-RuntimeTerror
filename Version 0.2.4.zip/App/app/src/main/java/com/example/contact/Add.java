package com.example.contact;

public class Add extends Contact
{

}
