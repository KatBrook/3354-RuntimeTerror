package com.example.contact;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;


public class ContactInfoPage extends AppCompatActivity {
    private EditText userNameInput;

    private static final int PICK_IMAGE_REQUEST_CODE = 1000;
    private static final int READ_EXTERNAL_STORAGE_REQUEST_CODE = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_info_page);
        //Have layout move up when keyboard appears
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

         userNameInput = findViewById(R.id.userNameInput);
        //Disable save button at start up (as no value has been entered)
        checkUsernameForEmptyValue();
        //set Listener for userNameInput
        userNameInput.addTextChangedListener(userNameTextWatcher);

    }

    //TextWatcher for save button
    private TextWatcher userNameTextWatcher = new TextWatcher()
    {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) { }
        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3)
        {
            //Check if Username has value entered
            checkUsernameForEmptyValue();
        }
        @Override
        public void afterTextChanged(Editable editable) { }
    };

    //Check if value was entered for username
    private void checkUsernameForEmptyValue()
    {
        Button saveButton = findViewById(R.id.saveButton);
        String userNameText = userNameInput.getText().toString();

        //Check if input has text
        if(userNameText.equals("")) //If no value is entered
        {
            saveButton.setEnabled(false); //Disable save button
        }
        else //If value is entered
        {
            saveButton.setEnabled(true); //Enable save button
        }
    }

    //Called when save button is pressed
    public Contact contactInformation()
    {
        //Create instantiation of Contact Class
        Contact contact = new Contact();

        //Contact Name
        userNameInput = findViewById(R.id.userNameInput);
        String userName = userNameInput.getText().toString();
        contact.setName(userName);

        //Contact Photo
        ImageView userImageInput = findViewById(R.id.contactPhoto);
        Bitmap userImage = userImageInput.getDrawingCache();
        contact.setContactImage(userImage);

        //Contact Cell Number
        EditText cellNumInput = findViewById(R.id.mobileNumInput);
        String cellNum = cellNumInput.getText().toString();
        contact.setMobileNumber(cellNum);

        //Contact Home Number
        EditText homeNumInput = findViewById(R.id.homeNumInput);
        String homeNum = homeNumInput.getText().toString();
        contact.setHomeNumber(homeNum);

        //Contact Work Number
        EditText workNumInput = findViewById(R.id.workNumInput);
        String workNum = workNumInput.getText().toString();
        contact.setWorkNumber(workNum);

        //Contact Email
        EditText emailInput = findViewById(R.id.emailInput);
        String email = emailInput.getText().toString();
        contact.setEmailAddress(email);

        //Contact Address
        EditText addressInput = findViewById(R.id.addressInput);
        String address = addressInput.getText().toString();
        contact.setAddress(address);

        return contact;
    }

    //If user taps on contact photo, allow user to upload picture from gallery
    public void contactPhotoClicked(View view)
    {
        pickImage();
    }

    private void pickImage()
    {
        if(ActivityCompat.checkSelfPermission(this, READ_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED)
        {
            //Step 1: Create Intent
            // (ACTION_GET_CONTENT allows user to select particular kind of data and return it)
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);

            //Step 2: Set intent type
            // (This indicates the type of data the intent wants returned to it)
            intent.setType("image/*");

            //Extras (Elaborate on what this does)
            intent.putExtra("crop", "true");
            intent.putExtra("scale", true);
            intent.putExtra("aspectX", 16);
            intent.putExtra("aspectY", 9);

            //Step 4: Call startActivityForResult method
            // (Starts another activity and receives a result back from it)
            startActivityForResult(intent, PICK_IMAGE_REQUEST_CODE);
        }
        else
        {
            String permissions[] = {READ_EXTERNAL_STORAGE};
            ActivityCompat.requestPermissions(this, permissions, READ_EXTERNAL_STORAGE_REQUEST_CODE);
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        //Implements functionality for when PICK_IMAGE_REQUEST_CODE is sent

        //If startActivityForResult starts with no errors
        if(requestCode == PICK_IMAGE_REQUEST_CODE)
        {
            //If there is error
            if(resultCode != RESULT_OK)
            {
                return;
            }
            Uri uri = data.getData();
            if(uri != null)
            {
                ImageView contactPhoto = findViewById(R.id.contactPhoto);
                contactPhoto.setImageURI(uri);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults)
    {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if(requestCode == READ_EXTERNAL_STORAGE_REQUEST_CODE)
        {
            //If the user allows permission
            if(grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                pickImage();
            }
        }
    }



    //If "cancel" button is pressed, return to main activity
    public void cancelButtonPressed(View view)
    {
        Intent openMainActivityIntent = new Intent(this, MainActivity.class);
        startActivity(openMainActivityIntent);
    }

    //When save button is pressed, save contact info
    public void saveButtonPressed(View view)
    {
        //Save contact information entered into instance of contact class
        Contact contact = contactInformation();
        //Call Contact Database
        ContactDB contactDB = ContactDB.getInstance();
        //Store information into database
        contactDB.addContactInfo(contact);

        //Pass new contact to contact list page to display
        //IMPLEMENT!!!!

        //Return to contact list page
        Intent openMainActivityIntent = new Intent(this, MainActivity.class);
        startActivity(openMainActivityIntent);
    }

}
