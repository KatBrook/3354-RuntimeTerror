package com.example.contact;

import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProvider;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;


public class ContactPage extends AppCompatActivity
{
    //Holds contact data passed from MainActivity. Will pass to AddEditContact if edit button is pressed.
    private int id;
    private String userName;
    private String imageFilePath;
    private String cellNum;
    private String homeNum;
    private String workNum;
    private String email;
    private String address;
    private boolean blacklisted;
    private TextView primaryText;
    private ImageView selectedContactPhoto;

    //Holds information for corresponding Layouts and TextViews.
    private RelativeLayout cellLayout;
    private TextView displayCell;
    private RelativeLayout homeLayout;
    private TextView displayHome;
    private RelativeLayout workLayout;
    private TextView displayWork;
    private LinearLayout emailLayout;
    private TextView displayEmail;
    private LinearLayout addressLayout;
    private TextView displayAddress;

    //Holds data for the text, call, and email buttons.
    private Button textButton;
    private Button callButton;
    private Button emailButton;
    private Button cellCallButton;
    private Button cellTextButton;
    private Button homeCallButton;
    private Button homeTextButton;
    private Button workCallButton;
    private Button workTextButton;

    //Holds data for the edit, delete, and blacklist buttons.
    private Button editButton;
    private Button deleteButton;
    private Button blacklistButton;

    //Number that main call/text buttons will reference (If mobile num null, use home num. If home num null, use work num. If work num null, no number was provided in contact)
    private String numberToCallText;

    //Used to update contact information in database after edit is made
    private ContactViewModel contactViewModel;




    public static final int EDIT_CONTACT_REQUEST = 2001;


    //-----------------------------------onCreate-----------------------------------//
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_page);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        createIDs();
        getContactData();
        displayPrimaryInfo();
        displayAllInfo();

        setPhoto();
        disableEnableCallTextButton();
        disableEnableEmailButton();

        //isBlacklisted = false;
    }


    //-----------------------------------setPhoto-----------------------------------//
    public void setPhoto()
    {
        if(imageFilePath != null) //If an image exists for the contact
        {
            try //If there is no error in getting file, convert to bitmap and set ImageViewer to display it
            {
                Bitmap selectedImage = BitmapFactory.decodeStream(new FileInputStream(new File(imageFilePath)));
                selectedContactPhoto.setImageBitmap(selectedImage);
            }
            catch(FileNotFoundException e) //If there is an error in displaying file, set photo to default image
            {
                e.printStackTrace();
                selectedContactPhoto.setImageResource(R.drawable.ic_user);
            }
        }
        else //If no image was passed, since no image was ever selected for contact, set image to default user photo
        {
            selectedContactPhoto.setImageResource(R.drawable.ic_user);
        }
    }

    //-----------------------------------disableEnableCallTextButton-----------------------------------//
    //If no phone number is provided for contact, disable call and text button. Else, enable them.
    public void disableEnableCallTextButton()
    {
        if(cellNum != null && !cellNum.isEmpty() && blacklisted == false) //If the contact has a cell number, the cell number is not empty, and the contact is not currently blacklisted
        {
            numberToCallText = cellNum;
            callButton.setEnabled(true);
            textButton.setEnabled(true);
        }
        else if(homeNum != null && !homeNum.isEmpty() && blacklisted == false) //If the contact has a home number, the home number is not empty, and the contact is not currently blacklisted
        {
            numberToCallText = homeNum;
            callButton.setEnabled(true);
            textButton.setEnabled(true);
        }
        else if(workNum != null && !workNum.isEmpty() && blacklisted == false) //If the contact has a work number, the work number is not empty, and the contact is not currently blacklisted
        {
            numberToCallText = workNum;
            callButton.setEnabled(true);
            textButton.setEnabled(true);
        }
        else //No numbers exist for contact
        {
            callButton.setEnabled(false); //Disable call button
            textButton.setEnabled(false); //Disable text button
            callButton.setBackground(ContextCompat.getDrawable(this,  R.drawable.ic_call_grey_60dp)); //Set color to grey to indicate that button is disabled
            textButton.setBackground(ContextCompat.getDrawable(this, R.drawable.ic_message_grey_60dp)); //Set color to grey to indicate that button is disabled
        }
    }

    //-----------------------------------disableEnableEmailButton-----------------------------------//
    //If no email address is provided for contact, disable email button. Else, enable it.
    public void disableEnableEmailButton()
    {
        if(email != null && !email.isEmpty() && blacklisted == false)
        {
            emailButton.setEnabled(true);
        }
        else //No email exists for contact
        {
            emailButton.setEnabled(false); //Disable email button
            emailButton.setBackground(ContextCompat.getDrawable(this, R.drawable.ic_email_grey_60dp)); //Set color to grey to indicate that button is disabled
        }
    }

    //-----------------------------------createIDs-----------------------------------//
    private void createIDs()
    {
        //Buttons.
        textButton = findViewById(R.id.textButton);
        callButton = findViewById(R.id.callButton);
        emailButton = findViewById(R.id.emailButton);
        editButton = findViewById(R.id.editButton);
        deleteButton = findViewById(R.id.deleteButton);
        blacklistButton = findViewById(R.id.blacklistButton);
        primaryText = findViewById(R.id.primaryText);
        selectedContactPhoto = findViewById(R.id.selectedContactPhoto);
        cellCallButton = findViewById(R.id.cellCallButton);
        cellTextButton = findViewById(R.id.cellTextButton);
        homeCallButton = findViewById(R.id.homeCallButton);
        homeTextButton = findViewById(R.id.homeTextButton);
        workCallButton = findViewById(R.id.workCallButton);
        workTextButton = findViewById(R.id.workTextButton);

        //Layouts and corresponding text.
        cellLayout = findViewById(R.id.cellLayout);
        displayCell = findViewById(R.id.displayCell);
        homeLayout = findViewById(R.id.homeLayout);
        displayHome = findViewById(R.id.displayHome);
        workLayout = findViewById(R.id.workLayout);
        displayWork = findViewById(R.id.displayWork);
        emailLayout = findViewById(R.id.emailLayout);
        displayEmail = findViewById(R.id.displayEmail);
        addressLayout = findViewById(R.id.addressLayout);
        displayAddress = findViewById(R.id.displayAddress);

    }

    //-----------------------------------getContactData-----------------------------------//
    //Get information from all fields of the contact.
    public void getContactData()
    {
        Intent intent = getIntent();
        if(intent != null)
        {
            id = intent.getIntExtra(Common.CONTACT_ID, -1);
            imageFilePath = intent.getStringExtra(Common.CONTACT_PHOTO);
            userName = intent.getStringExtra(Common.CONTACT_USERNAME);
            cellNum = intent.getStringExtra(Common.CONTACT_MOBILE);
            homeNum = intent.getStringExtra(Common.CONTACT_HOME);
            workNum = intent.getStringExtra(Common.CONTACT_WORK);
            email = intent.getStringExtra(Common.CONTACT_EMAIL);
            address = intent.getStringExtra(Common.CONTACT_ADDRESS);
            blacklisted = intent.getBooleanExtra(Common.CONTACT_BLACKLISTED, false);
        }
    }

    //-----------------------------------displayPrimaryInfo-----------------------------------//
    //Go through all fields of the contact, and display the first available information at the top of the contact.
    public void displayPrimaryInfo()
    {
        if(userName != null && !userName.isEmpty()) //If the contact has a name, set primaryText to the name
        {
            primaryText.setText(userName);
        }
        else if(cellNum != null && !cellNum.isEmpty()) //If the contact has a cell number, set primaryText to the cell number
        {
            primaryText.setText(cellNum);
        }
        else if(homeNum != null && !homeNum.isEmpty()) //If the contact has a home number, set primaryText to the home number
        {
            primaryText.setText(homeNum);
        }
        else if(workNum != null && !workNum.isEmpty()) //If the contact has a work number, set primaryText to the work number
        {
            primaryText.setText(workNum);
        }
        else if(email != null && !email.isEmpty()) //If the contact has ane email, set primaryText to the email
        {
            primaryText.setText(email);
        }
        else if(address != null && !address.isEmpty()) //If the contact has an address, set primaryText to the address
        {
            primaryText.setText(address);
        }
        else // Otherwise, primaryText will be blank
        {
            primaryText.setText("N/A");
        }
    }

    //-----------------------------------displayAllInfo-----------------------------------//
    //Fills out the corresponding fields of a contact and displays it on the contact's page.
    public void displayAllInfo()
    {
        if(cellNum != null && !cellNum.isEmpty()) //If the contact has a cell number, display it next to "CELL:"
        {
            displayCell.setText(cellNum);
        } else //Otherwise, remove the "CELL:" section entirely
        {
            cellLayout.setVisibility(View.GONE);
        }

        if(homeNum != null && !homeNum.isEmpty()) //If the contact has a home number, display it next to "HOME:"
        {
            displayHome.setText(homeNum);
        } else //Otherwise, remove the "HOME:" section entirely
        {
            homeLayout.setVisibility(View.GONE);
        }

        if(workNum != null && !workNum.isEmpty()) //If the contact has a work number, display it next to "WORK:"
        {
            displayWork.setText(workNum);
        } else //Otherwise, remove the "WORK:" section entirely
        {
            workLayout.setVisibility(View.GONE);
        }

        if(email != null && !email.isEmpty()) //If the contact has an email, display it next to "EMAIL:"
        {
            displayEmail.setText(email);
        } else //Otherwise, remove the "EMAIL:" section entirely
        {
            emailLayout.setVisibility(View.GONE);
        }

        if(address != null && !address.isEmpty()) //If the contact has an address, display it next to "ADDRESS:"
        {
            displayAddress.setText(address);
        } else //Otherwise, remove the "ADDRESS:" section entirely
        {
            addressLayout.setVisibility(View.GONE);
        }
    }

    //-----------------------------------backButtonPressed-----------------------------------//
    //Pressing the BACK button will take the user back to the main page of the Contacts app.
    public void backButtonPressed(View view)
    {
        Intent openMainActivityIntent = new Intent(this, MainActivity.class);
        startActivity(openMainActivityIntent);
    }

    //-----------------------------------callButtonPressed-----------------------------------//
    //Pressing the CALL button will take the user out of the Contacts app and to the call-app.
    public void callButtonPressed(View view)
    {
        if(numberToCallText != null && !numberToCallText.isEmpty())
        {
            Intent openCallActivity = new Intent(Intent.ACTION_DIAL);
            openCallActivity.setData(Uri.parse("tel:" + numberToCallText));
            startActivity(openCallActivity);
        }
    }

    //-----------------------------------textButtonPressed-----------------------------------//
    //Pressing the TEXT button will take the user out of the Contacts app and to the text-app.
    public void textButtonPressed(View view)
    {
        if(numberToCallText != null && !numberToCallText.isEmpty())
        {
            Intent  openSMSActivity = new Intent(Intent.ACTION_VIEW);
            openSMSActivity.setData(Uri.parse("sms:" + numberToCallText));
            startActivity(openSMSActivity);
        }
    }

    //-----------------------------------emailButtonPressed-----------------------------------//
    //Pressing the EMAIL button will take the user out of the Contacts app and to the email-app.
    public void emailButtonPressed(View view)
    {
        if(email != null && !email.isEmpty())
        {
            Intent intentEmail = new Intent(Intent.ACTION_VIEW);
            intentEmail.setData(Uri.parse("mailto:" + email));
            startActivity(intentEmail);
        }
    }

    public void cellCallButtonPressed(View view) {
    if(cellNum != null && !cellNum.isEmpty())
    {
        Intent openCallActivity = new Intent(Intent.ACTION_DIAL);
        openCallActivity.setData(Uri.parse("tel:" + cellNum));
        startActivity(openCallActivity);
    }
}

    public void cellTextButtonPressed(View view) {
        if(cellNum != null && !cellNum.isEmpty())
        {
            Intent  openSMSActivity = new Intent(Intent.ACTION_VIEW);
            openSMSActivity.setData(Uri.parse("sms:" + cellNum));
            startActivity(openSMSActivity);
        }
    }

    public void homeCallButtonPressed(View view) {
        if(homeNum != null && !homeNum.isEmpty())
        {
            Intent openCallActivity = new Intent(Intent.ACTION_DIAL);
            openCallActivity.setData(Uri.parse("tel:" + homeNum));
            startActivity(openCallActivity);
        }
    }

    public void homeTextButtonPressed(View view) {
        if(homeNum != null && !homeNum.isEmpty())
        {
            Intent  openSMSActivity = new Intent(Intent.ACTION_VIEW);
            openSMSActivity.setData(Uri.parse("sms:" + homeNum));
            startActivity(openSMSActivity);
        }
    }

    public void workCallButtonPressed(View view) {
        if(workNum != null && !workNum.isEmpty())
        {
            Intent openCallActivity = new Intent(Intent.ACTION_DIAL);
            openCallActivity.setData(Uri.parse("tel:" + workNum));
            startActivity(openCallActivity);
        }
    }

    public void workTextButtonPressed(View view) {
        if(workNum != null && !workNum.isEmpty())
        {
            Intent  openSMSActivity = new Intent(Intent.ACTION_VIEW);
            openSMSActivity.setData(Uri.parse("sms:" + workNum));
            startActivity(openSMSActivity);
        }
    }

    //-----------------------------------editButtonPressed-----------------------------------//
    //Pressing the EDIT button will take the user to the Add/Edit Contact page, where the user can make adjustments as necessary.
    public void editButtonPressed(View view)
    {
        Intent intent = new Intent(ContactPage.this, AddEditContact.class);
        intent.putExtra(Common.CONTACT_ID, id); //Pass to AddEditContact to later pass back to MainActivity in order to tell database what contact to update
        intent.putExtra(Common.CONTACT_USERNAME, userName);
        intent.putExtra(Common.CONTACT_PHOTO, imageFilePath);
        intent.putExtra(Common.CONTACT_MOBILE, cellNum);
        intent.putExtra(Common.CONTACT_HOME, homeNum);
        intent.putExtra(Common.CONTACT_WORK, workNum);
        intent.putExtra(Common.CONTACT_EMAIL, email);
        intent.putExtra(Common.CONTACT_ADDRESS, address);
        startActivityForResult(intent, EDIT_CONTACT_REQUEST);
    }

    //-----------------------------------deleteButtonPressed-----------------------------------//
    //When the DELETE button is pressed, prompt the user with a confirmation dialog. If user presses 'Yes', carry out deletion. Otherwise, do not delete the contact.
    public void deleteButtonPressed(View view)
    {
        //Create the dialog prompt and set the title and corresponding text
        Builder builder = new Builder(this);
        builder.setTitle("Deleting contact");
        builder.setMessage("You are about to delete this contact. \n\nDo you wish to proceed?");
        builder.setCancelable(false);

        //Call the delete() function if the user selects 'Yes'.
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                delete();
            }
        });

        //Otherwise, do nothing if the user selects 'No'.
        builder.setNegativeButton("No", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialogInterface, int i)
            {

            }
        });

        builder.show();
    }

    //-----------------------------------delete-----------------------------------//
    //Carries out the actual process of deleting a contact. Called by deleteButtonPressed().
    public void delete()
    {
        //Add fields to contact object
        Contact contact = new Contact(imageFilePath, userName, cellNum, homeNum, workNum, email, address);
        contact.setId(id); //Pass in primary key so database can identify which contact to update
        contactViewModel = new ViewModelProvider(this).get(ContactViewModel.class);
        contactViewModel.deleteContact(contact);

        //Return to main activity
        Intent openMainActivityIntent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(openMainActivityIntent);
    }

    //-----------------------------------blacklistButtonPressed-----------------------------------//
    //When the BLACKLIST button is pressed, perform corresponding action depending on whether contact is already blacklisted or not.
    public void blacklistButtonPressed(View view)
    {
        if(blacklisted == false) //If the contact is currently NOT blacklisted
        {
            confirmBlacklist();
        } else //Otherwise, the contact is currently blacklisted
        {
            confirmUnBlacklist();
        }
    }

    //-----------------------------------confirmBlacklist-----------------------------------//
    //Method for carrying out blacklist process if contact has NOT been blacklisted yet.
    public void confirmBlacklist()
    {
        //Create the dialog prompt and set the title and corresponding text
        Builder builder = new Builder(this);
        builder.setTitle("Blacklisting contact");
        builder.setMessage("You are about to blacklist this contact. You will no longer be able to call, text, or email this contact. \n\nDo you wish to proceed?");
        builder.setCancelable(false);

        //Disable any enabled CALL / TEXT / EMAIL buttons for the contact if the user selects 'Yes'
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                blacklisted = true; //Set the contact's blacklist status Boolean to 'true'

                if(callButton.isEnabled()) //If the contact has at least one phone number parameter
                {
                    callButton.setEnabled(false); //Disable call button
                    callButton.setBackground(ContextCompat.getDrawable(getApplicationContext(),  R.drawable.ic_call_grey_60dp)); //Set color to grey to indicate that button is disabled
                }

                if(textButton.isEnabled()) //If the contact has at least one phone number parameter
                {
                    textButton.setEnabled(false); //Disable text button
                    textButton.setBackground(ContextCompat.getDrawable(getApplicationContext(), R.drawable.ic_message_grey_60dp)); //Set color to grey to indicate that button is disabled
                }

                if(emailButton.isEnabled()) //If the contact has an email
                {
                    emailButton.setEnabled(false); //Disable email button
                    emailButton.setBackground(ContextCompat.getDrawable(getApplicationContext(), R.drawable.ic_email_grey_60dp)); //Set color to grey to indicate that button is disabled
                }

                if(cellCallButton.isEnabled())
                {
                    cellCallButton.setEnabled(false);
                    cellCallButton.setBackground(ContextCompat.getDrawable(getApplicationContext(),  R.drawable.ic_call_grey_60dp));
                }

                if(cellTextButton.isEnabled())
                {
                    cellTextButton.setEnabled(false);
                    cellTextButton.setBackground(ContextCompat.getDrawable(getApplicationContext(), R.drawable.ic_message_grey_60dp));;
                }

                if(homeCallButton.isEnabled())
                {
                    homeCallButton.setEnabled(false);
                    homeCallButton.setBackground(ContextCompat.getDrawable(getApplicationContext(),  R.drawable.ic_call_grey_60dp));
                }

                if(homeTextButton.isEnabled())
                {
                    homeTextButton.setEnabled(false);
                    homeTextButton.setBackground(ContextCompat.getDrawable(getApplicationContext(), R.drawable.ic_message_grey_60dp));;
                }

                if(workCallButton.isEnabled())
                {
                    workCallButton.setEnabled(false);
                    workCallButton.setBackground(ContextCompat.getDrawable(getApplicationContext(),  R.drawable.ic_call_grey_60dp));
                }

                if(workTextButton.isEnabled())
                {
                    workTextButton.setEnabled(false);
                    workTextButton.setBackground(ContextCompat.getDrawable(getApplicationContext(), R.drawable.ic_message_grey_60dp));
                }
            }
        });

        //Otherwise, do nothing if the user selects selects 'No', and contact will remain in current blacklisted / un-blacklisted status
        builder.setNegativeButton("No", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialogInterface, int i)
            {

            }
        });

        builder.show();
    }

    //-----------------------------------confirmUnBlacklist-----------------------------------//
    //Method for carrying out un-blacklist process if contact HAS been blacklisted.
    public void confirmUnBlacklist()
    {
        //Create the dialog prompt and set the title and corresponding text
        Builder builder = new Builder(this);
        builder.setTitle("Un-blacklisting contact");
        builder.setMessage("You are about to un-blacklist this contact. You will be able to call, text, or email this contact. \n\nDo you wish to proceed?");
        builder.setCancelable(false);

        //Enable the corresponding CALL / TEXT / EMAIL buttons for the contact if the user selects 'Yes'
        //Should only enable buttons if the contact has the corresponding parameters to either CALL / TEXT / EDIT
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialogInterface, int i)
            {
                blacklisted = false; //Set the contact's blacklist status Boolean to 'false'

                if((cellNum != null && !cellNum.isEmpty()) || (homeNum != null && !homeNum.isEmpty()) || (workNum != null && !workNum.isEmpty())) //If the contact has at least one phone number
                {
                    callButton.setEnabled(true); //Enable call button
                    textButton.setEnabled(true); //Enable text button
                    callButton.setBackground(ContextCompat.getDrawable(getApplicationContext(),  R.drawable.ic_call_green_60dp)); //Set color to green to indicate that button is enabled
                    textButton.setBackground(ContextCompat.getDrawable(getApplicationContext(), R.drawable.ic_message_blue_60dp)); //Set color to blue to indicate that button is enabled
                }

                if(email != null && !email.isEmpty()) //If the contact has an email
                {
                    emailButton.setEnabled(true); //Enable email button
                    emailButton.setBackground(ContextCompat.getDrawable(getApplicationContext(), R.drawable.ic_email_orange_60dp)); //Set color to orange to indicate that button is enabled
                }

                if(cellNum != null && !cellNum.isEmpty())
                {
                    cellCallButton.setEnabled(true);
                    cellTextButton.setEnabled(true);
                    cellCallButton.setBackground(ContextCompat.getDrawable(getApplicationContext(),  R.drawable.ic_call_green_60dp));
                    cellTextButton.setBackground(ContextCompat.getDrawable(getApplicationContext(), R.drawable.ic_message_blue_60dp));
                }

                if(homeNum != null && !homeNum.isEmpty())
                {
                    homeCallButton.setEnabled(true);
                    homeTextButton.setEnabled(true);
                    homeCallButton.setBackground(ContextCompat.getDrawable(getApplicationContext(),  R.drawable.ic_call_green_60dp));
                    homeTextButton.setBackground(ContextCompat.getDrawable(getApplicationContext(), R.drawable.ic_message_blue_60dp));
                }

                if(workNum != null && !workNum.isEmpty())
                {
                    workCallButton.setEnabled(true);
                    workTextButton.setEnabled(true);
                    workCallButton.setBackground(ContextCompat.getDrawable(getApplicationContext(),  R.drawable.ic_call_green_60dp));
                    workTextButton.setBackground(ContextCompat.getDrawable(getApplicationContext(), R.drawable.ic_message_blue_60dp));
                }
            }
        });

        //Otherwise, do nothing if the user selects 'No'
        builder.setNegativeButton("No", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialogInterface, int i)
            {

            }
        });

        builder.show();
    }

    //-----------------------------------onActivityResult-----------------------------------//
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        //If requestCode to edit contact is sent and there is no error
        if(requestCode == EDIT_CONTACT_REQUEST)
        {
            if(resultCode == RESULT_OK)
            {
                int id = data.getIntExtra(Common.CONTACT_ID, -1);

                if(id == -1) //If something went wrong retrieving id
                {
                    Toast.makeText(this, "Error. Changes to contact could not be saved", Toast.LENGTH_SHORT).show();
                    //Return to main activity
                    Intent openMainActivityIntent = new Intent(this, MainActivity.class);
                    startActivity(openMainActivityIntent);
                }

                //Retrieve contact information from AddEditContact page
                String contactPhoto = data.getStringExtra(Common.CONTACT_PHOTO);
                String userName = data.getStringExtra(Common.CONTACT_USERNAME);
                String cellNum = data.getStringExtra(Common.CONTACT_MOBILE);
                String homeNum = data.getStringExtra(Common.CONTACT_HOME);
                String workNum = data.getStringExtra(Common.CONTACT_WORK);
                String email = data.getStringExtra(Common.CONTACT_EMAIL);
                String address = data.getStringExtra(Common.CONTACT_ADDRESS);

                //Add fields to contact object
                Contact contact = new Contact(contactPhoto, userName, cellNum, homeNum, workNum, email, address);
                contact.setId(id); //Pass in primary key so database can identify which contact to update

                contactViewModel = new ViewModelProvider(this).get(ContactViewModel.class);
                contactViewModel.updateContact(contact);

                //Display toast informing user that changes to contact have been saved.
                Toast.makeText(this, "Contact updated", Toast.LENGTH_SHORT).show();

                //Return to main activity
                Intent openMainActivityIntent = new Intent(this, MainActivity.class);
                startActivity(openMainActivityIntent);
            }
            else //If there was an error in editing contact
            {
                //Display toast informing user that changed to contact could not be saved.
                Toast.makeText(this, "Error. Changes to contact could not be saved", Toast.LENGTH_SHORT).show();

                //Return to main activity
                Intent openMainActivityIntent = new Intent(this, MainActivity.class);
                startActivity(openMainActivityIntent);
            }
        }
    }

    //-----------------------------------onRequestPermissionsResult-----------------------------------//
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults)
    {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

    }
}
