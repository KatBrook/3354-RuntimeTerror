package com.example.contact;

public class Contact extends ContactDB
{
    private String name;

    private String mobileNumber;
    private String homeNumber;
    private String workNumber;

    private String emailAddress;
    private String address;

    public String getName()
    {
        return name;
    }
    public void setName(String name)
    {
        this.name = name;
    }

    public String getMobileNumber()
    {
        return mobileNumber;
    }
    public void setMobileNumber(String mobileNumber)
    {
        this.mobileNumber = mobileNumber;
    }
    public String getHomeNumber()
    {
        return homeNumber;
    }
    public void setHomeNumber(String homeNumber)
    {
        this.homeNumber = homeNumber;
    }
    public String getWorkNumber() { return workNumber; }
    public void setWorkNumber(String workNumber)
    {
        this.workNumber = workNumber;
    }

    public String getEmailAddress()
    {
        return emailAddress;
    }
    public void setEmailAddress(String emailAddress)
    {
        this.emailAddress = emailAddress;
    }
    public String getAddress()
    {
        return address;
    }
    public void setAddress(String address)
    {
        this.address = address;
    }
}
