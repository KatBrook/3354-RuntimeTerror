package com.example.contact;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

//Stores variables and methods accessed by several classes
public class Common
{
    public static final int PICK_IMAGE_REQUEST_CODE = 1000;
    public static final int READ_EXTERNAL_STORAGE_REQUEST_CODE = 1001;

    public static final int ADD_CONTACT_REQUEST = 2000;
    public static final int EDIT_CONTACT_REQUEST = 2001;

    public static final int ADD_GROUP_REQUEST = 3000;
    public static final int EDIT_GROUP_REQUEST = 3001;

    public static final int ADD_GROUP_MEMBER_REQUEST = 4000;

    public static final int VIEWTYPE_CONTACT = 9000;
    public static final int VIEWTYPE_LETTER_CONTACT = 9001;

    public static final int VIEWTYPE_GROUP = 8000;
    public static final int VIEWTYPE_LETTER_GROUP = 8001;

    //Contact
    public static final String CONTACT_ID = "com.example.contact.CONTACT_ID";
    public static final String CONTACT_USERNAME = "com.example.contact.CONTACT_USERNAME";
    public static final String CONTACT_PHOTO = "com.example.contact.CONTACT_PHOTO";
    public static final String CONTACT_MOBILE = "com.example.contact.CONTACT_MOBILE";
    public static final String CONTACT_HOME = "com.example.contact.CONTACT_HOME";
    public static final String CONTACT_WORK = "com.example.contact.CONTACT_WORK";
    public static final String CONTACT_EMAIL = "com.example.contact.CONTACT_EMAIL";
    public static final String CONTACT_ADDRESS = "com.example.contact.CONTACT_ADDRESS";
    public static final String CONTACT_BLACKLISTED = "com.example.contact.BLACKLISTED";

    //Group
    public static final String GROUP_ID = "com.example.contact.GROUP_ID";
    public static final String GROUP_NAME = "com.example.contact.GROUP_NAME";
    public static final String GROUP_PHOTO = "com.example.contact.GROUP_PHOTO";
    public static final String GROUP_MEMBERS = "com.example.contact.GROUP_MEMBERS";

    public static List<String> alphabet_available = new ArrayList<>();


    //Sort list of contacts alphabetically
    public static List<Contact> sortContactList(List<Contact> contact)
    {
        Collections.sort(contact, new Comparator<Contact>()
        {
            @Override
            public int compare(Contact o1, Contact o2)
            {
                return o1.getName().compareTo(o2.getName());
            }
        });
        return contact;
    }
    //Sort list of groups alphabetically
    public static List<Group> sortGroupList(List<Group> group)
    {
        Collections.sort(group, new Comparator<Group>()
        {
            @Override
            public int compare(Group o1, Group o2)
            {
                return o1.getGroupName().compareTo(o2.getGroupName());
            }
        });
        return group;
    }

    //Get characters to display above groups
    public static List<Group> addAlphabetsGroup(List<Group> list)
    {
        ArrayList<Group> customListGroup = new ArrayList<>();

        //Make sure list isn't null
        if(!list.isEmpty())
        {
            int i;
            Group firstPosition;

            if(list.get(0).getGroupName() != null && !list.get(0).getGroupName().isEmpty())
            {
                firstPosition = new Group(String.valueOf(list.get(0).getGroupName().toUpperCase().charAt(0)), VIEWTYPE_LETTER_GROUP);
                alphabet_available.add(String.valueOf(list.get(0).getGroupName().toUpperCase().charAt(0))); //Add first character of Group to Group header list
            }
            else //If name is null
            {
                firstPosition = new Group(String.valueOf('#'), VIEWTYPE_LETTER_GROUP); //Assign '#' as Char so Groups with no names appear under '#' header
                alphabet_available.add("#"); //Add first character of Group to Group header list
            }

            customListGroup.add(firstPosition);

            for(i = 0; i < list.size() - 1; i++)
            {
                char name1;
                char name2;

                if(list.get(i).getGroupName() != null && !list.get(i).getGroupName().isEmpty())
                {
                    name1 = list.get(i).getGroupName().toUpperCase().charAt(0); //Get first character in name
                }
                else //If name is null
                {
                    name1 = '#';
                }

                if(list.get(i + 1).getGroupName() != null && !list.get(i + 1).getGroupName().isEmpty())
                {
                    name2 = list.get(i + 1).getGroupName().toUpperCase().charAt(0); //Get first character in next name
                }
                else //If name is null
                {
                    name2 = '#';
                }


                if(name1 == name2)
                {
                    customListGroup.add(list.get(i)); //If next group has same first letter in name, add to list as default Group
                }
                else //If first letter of next Group is different than first letter of current Group, specify Group as a letter
                {
                    customListGroup.add(list.get(i));
                    Group group = new Group(String.valueOf(name2), VIEWTYPE_LETTER_GROUP);
                    alphabet_available.add(String.valueOf(name2));
                    customListGroup.add(group);
                }
            }
            customListGroup.add(list.get(i));
        }
        return customListGroup;
    }

    //Get characters to display above contacts
    public static List<Contact> addAlphabetsContact(List<Contact> list)
    {
        ArrayList<Contact> customListContact = new ArrayList<>();

        //Make sure list isn't null
        if(!list.isEmpty())
        {
            int i;
            Contact firstPosition;

            if(list.get(0).getName() != null && !list.get(0).getName().isEmpty())
            {
                firstPosition = new Contact(String.valueOf(list.get(0).getName().toUpperCase().charAt(0)), VIEWTYPE_LETTER_CONTACT);
                alphabet_available.add(String.valueOf(list.get(0).getName().toUpperCase().charAt(0))); //Add first character of contact to contact header list
            }
            else //If name is null
            {
                firstPosition = new Contact(String.valueOf('#'), VIEWTYPE_LETTER_CONTACT); //Assign '#' as Char so contacts with no names appear under '#' header
                alphabet_available.add("#"); //Add first character of contact to contact header list
            }

            customListContact.add(firstPosition);

            for(i = 0; i < list.size() - 1; i++)
            {
                char name1;
                char name2;

                if(list.get(i).getName() != null && !list.get(i).getName().isEmpty())
                {
                    name1 = list.get(i).getName().toUpperCase().charAt(0); //Get first character in name
                }
                else //If name is null
                {
                    name1 = '#';
                }

                if(list.get(i + 1).getName() != null && !list.get(i + 1).getName().isEmpty())
                {
                    name2 = list.get(i + 1).getName().toUpperCase().charAt(0); //Get first character in next name
                }
                else //If name is null
                {
                    name2 = '#';
                }


                if(name1 == name2)
                {
                    customListContact.add(list.get(i)); //If next contact has same first letter in name, add to list as default contact
                }
                else //If first letter of next context is different than first letter of current contact, specify contact as a letter
                {
                    customListContact.add(list.get(i));
                    Contact contact = new Contact(String.valueOf(name2), VIEWTYPE_LETTER_CONTACT);
                    alphabet_available.add(String.valueOf(name2));
                    customListContact.add(contact);
                }
            }
            customListContact.add(list.get(i));
        }
        return customListContact;
    }

    //Returns position of contact (by name) in list
    public static int findPositionWithNameContact(String name, List<Contact> list)
    {
        for(int i = 0; i < list.size(); i++)
        {
            if(list.get(i).getName().toUpperCase().equals(name))
            {
                return i;
            }
        }
        return -1; //If name not found
    }
    //Returns position of group (by name) in list
    public static int findPositionWithNameGroup(String groupName, List<Group> list)
    {
        for(int i = 0; i < list.size(); i++)
        {
            if(list.get(i).getGroupName().toUpperCase().equals(groupName))
            {
                return i;
            }
        }
        return -1; //If name not found
    }

    //Creates Alphabet list
    public static List<String> generateAlphabet()
    {
        ArrayList<String> result = new ArrayList<>();
        for(int i = 65; i <= 90; i++) //A = 65 in ASCII and Z = 90 in ASCII
        {
            char character = (char) i;
            result.add(String.valueOf(character));
        }

        return result;
    }

}
