package com.example.contact;

import android.telephony.PhoneNumberUtils;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import java.util.Locale;
import java.util.UUID;

//Contains attributes that make up a contact. Used for Room Database
@Entity
public class Contact
{
    @PrimaryKey
    @NonNull
    private String id = UUID.randomUUID().toString();

    private String contactImagePath;
    private String name;
    private String mobileNumber;
    private String homeNumber;
    private String workNumber;
    private String emailAddress;
    private String address;
    private boolean blacklisted = false;

    private int viewTypeContact = Common.VIEWTYPE_CONTACT; //Have default be contact

    //For creating letters for contacts
    @Ignore //Tell Room Database to ignore this constructor
    public Contact(String name, int viewTypeContact)
    {
        this.name = name;
        setViewTypeContact(viewTypeContact);
    }
    //For creating contacts
    public Contact(String contactImagePath,
                   String name,
                   String mobileNumber,
                   String homeNumber,
                   String workNumber,
                   String emailAddress,
                   String address)
    {
        this.contactImagePath = contactImagePath;
        this.name = name;

        if (mobileNumber != null && !mobileNumber.isEmpty()) //If mobile number contains value, format to phone number
        {
            this.mobileNumber = PhoneNumberUtils.formatNumber(mobileNumber, Locale.getDefault().getCountry());
        }
        else
        {
            this.mobileNumber = mobileNumber;
        }

        if (homeNumber != null && !homeNumber.isEmpty()) //If home number contains value, format to phone number
        {
            this.homeNumber = PhoneNumberUtils.formatNumber(homeNumber, Locale.getDefault().getCountry());
        }
        else
        {
            this.homeNumber = homeNumber;
        }

        if(workNumber != null && !workNumber.isEmpty()) //If work number contains value, format to phone number
        {
            this.workNumber = PhoneNumberUtils.formatNumber(workNumber, Locale.getDefault().getCountry());
        }
        else
        {
            this.workNumber = workNumber;
        }

        this.emailAddress = emailAddress;
        this.address = address;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getId()
    {
        return id;
    }

    public String getContactImagePath()
    {
        return contactImagePath;
    }

    public String getName()
    {
        if(name != null && !name.isEmpty() && !name.trim().isEmpty())
        {
            return name;
        }
        else //If no name is entered, set name equal to "Unknown Name"
        {
            return "Unknown Name";
        }

    }

    public String getMobileNumber()
    {
        return mobileNumber;
    }

    public String getHomeNumber()
    {
        return homeNumber;
    }

    public String getWorkNumber()
    {
        return workNumber;
    }

    public String getEmailAddress()
    {
        return emailAddress;
    }

    public String getAddress()
    {
        return address;
    }

    public boolean getBlacklisted() { return blacklisted; }

    public int getViewTypeContact()
    {
        return viewTypeContact;
    }

    public void setViewTypeContact(int viewTypeContact)
    {
        this.viewTypeContact = viewTypeContact;
    }

    public void setBlacklisted(boolean status) { blacklisted = status; }


}
