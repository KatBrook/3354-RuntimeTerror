package com.example.contact;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

//Shows information for group (Name, Photo, Members)
public class GroupPage extends AppCompatActivity
{
    //Group Data
    private String groupId;
    private String groupName;
    private String groupImageFilePath;
    private ArrayList<String> groupMemberIDs;
    private GroupViewModel groupViewModel;

    //Group Page Fields
    TextView groupNameTextView;
    ImageView groupPhoto;

    //Tools to display contacts that make up group
    private ContactAdapter contactAdapter;
    private ContactViewModel contactViewModel;
    private RecyclerView recyclerView;
    private List<Contact> contactsSorted;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_page);
        setTitle("Group Information"); //Set title of toolbar for activity
        createIDs();

        //Get group information
        Intent intent = getIntent();
        if(intent != null)
        {
            groupId = intent.getStringExtra(Common.GROUP_ID);
            groupName = intent.getStringExtra(Common.GROUP_NAME);
            groupImageFilePath = intent.getStringExtra(Common.GROUP_PHOTO);
            groupMemberIDs = intent.getStringArrayListExtra(Common.GROUP_MEMBERS);
        }

        displayGroupInformation();
        setPhoto();

        //Set up RecycleView
        recyclerView = findViewById(R.id.member_list);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager); //Every RecyclerView needs a layout manager
        recyclerView.addItemDecoration(new DividerItemDecoration(this, layoutManager.getOrientation()));
        recyclerView.setHasFixedSize(true);


        contactAdapter = new ContactAdapter();
        recyclerView.setAdapter(contactAdapter); //Populate RecyclerView with list of contacts in adapter

        //Gain access to ContactViewModel
        contactViewModel = new ViewModelProvider(this).get(ContactViewModel.class);

        //If activity is in foreground and list of contacts have changed, update RecyclerView
        contactViewModel.getAllContacts().observe(this, new Observer<List<Contact>>()
        {
            @Override
            public void onChanged(List<Contact> contacts) //Updates RecyclerView whenever there is a change in the list of contacts
            {
                //Sort contacts
                contactsSorted = Common.sortContactList(contacts);

                List<Contact> groupMembers = new ArrayList<>(); //Will hold contacts user selected to be in group

                //Go through all contacts and put contacts user selected as group members in groupMembers ArrayList
                for(int i = 0; i < contactsSorted.size(); i++)
                {
                    for(int j = 0; j < groupMemberIDs.size(); j++)
                    {
                        if(contactsSorted.get(i).getId().equals(groupMemberIDs.get(j)))
                        {
                            groupMembers.add(contactsSorted.get(i));
                        }
                    }
                }

                //Add letter headers to list
                groupMembers = Common.addAlphabetsContact(groupMembers);

                contactAdapter.setContacts(groupMembers);
            }
        });

        contactAdapter.setOnItemClickListener(new ContactAdapter.OnItemClickListener()
        {
            @Override
            public void onItemClick(Contact contact)
            {
                //Open Contact Page Activity (where contact can be edited or deleted)

                Intent intent = new Intent(GroupPage.this, ContactPage.class);

                //Pass data from contact object to ContactPage
                intent.putExtra(Common.CONTACT_ID, contact.getId()); //Pass to AddEditContact to later pass back to MainActivity in order to tell database what contact to update
                intent.putExtra(Common.CONTACT_USERNAME, contact.getName());
                intent.putExtra(Common.CONTACT_PHOTO, contact.getContactImagePath());
                intent.putExtra(Common.CONTACT_MOBILE, contact.getMobileNumber());
                intent.putExtra(Common.CONTACT_HOME, contact.getHomeNumber());
                intent.putExtra(Common.CONTACT_WORK, contact.getWorkNumber());
                intent.putExtra(Common.CONTACT_EMAIL, contact.getEmailAddress());
                intent.putExtra(Common.CONTACT_ADDRESS, contact.getAddress());
                intent.putExtra(Common.CONTACT_BLACKLISTED, contact.getBlacklisted());

                startActivity(intent);
            }
        });
    }

    public void createIDs()
    {
        groupNameTextView = findViewById(R.id.groupName);
        groupPhoto = findViewById(R.id.groupPhoto);
    }

    public void displayGroupInformation()
    {
        groupNameTextView.setText(groupName);
    }

    public void setPhoto()
    {
        if(groupImageFilePath != null) //If an image exists for the group
        {
            try //If there is no error in getting file, convert to bitmap and set ImageViewer to display it
            {
                Bitmap selectedImage = BitmapFactory.decodeStream(new FileInputStream(new File(groupImageFilePath)));
                groupPhoto.setImageBitmap(selectedImage);
            }
            catch(FileNotFoundException e) //If there is an error in displaying file, set photo to default image
            {
                e.printStackTrace();
                groupPhoto.setImageResource(R.drawable.ic_user);
            }
        }
        else //If no image was passed, since no image was ever selected for contact, set image to default user photo
        {
            groupPhoto.setImageResource(R.drawable.ic_user);
        }
    }

    public void deleteGroupButtonPressed(View view)
    {
        //Create the dialog prompt and set the title and corresponding text
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Deleting group");
        builder.setMessage("You are about to delete this group. \n\nDo you wish to proceed?");
        builder.setCancelable(false);

        //Call the delete() function if the user selects 'Yes'.
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i)
            {
                delete();
            }
        });

        //Otherwise, do nothing if the user selects 'No'.
        builder.setNegativeButton("No", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialogInterface, int i)
            {
                //Do nothing
            }
        });

        builder.show();
    }

    public void delete()
    {
        Group group = new Group(groupImageFilePath, groupName, groupMemberIDs);
        group.setId(groupId); //Pass in primary key so database can identify which group to delete
        groupViewModel = new ViewModelProvider(this).get(GroupViewModel.class);
        groupViewModel.deleteGroup(group);

        //Return to GroupList
        Intent openGroupList = new Intent(getApplicationContext(), GroupList.class);
        startActivity(openGroupList);
    }

    public void editGroupButtonPressed(View view) //If edit button is pressed, pass information to AddEditGroupPage
    {
        Intent intent = new Intent(GroupPage.this, AddEditGroupPage.class);
        intent.putExtra(Common.GROUP_ID, groupId);
        intent.putExtra(Common.GROUP_NAME, groupName);
        intent.putExtra(Common.GROUP_PHOTO, groupImageFilePath);
        intent.putExtra(Common.GROUP_MEMBERS, groupMemberIDs);
        startActivityForResult(intent, Common.EDIT_GROUP_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        //If requestCode to edit group is sent and there is no error
        if(requestCode == Common.EDIT_GROUP_REQUEST)
        {
            if(resultCode == RESULT_OK)
            {
                String groupId = data.getStringExtra(Common.GROUP_ID);

                if(groupId == String.valueOf(-1)) //If something went wrong retrieving id
                {
                    Toast.makeText(this, "Error. Changes to group could not be saved", Toast.LENGTH_SHORT);
                    //Return to GroupList
                    Intent openGroupListIntent = new Intent(this, GroupList.class);
                    startActivity(openGroupListIntent);
                }

                //Retrieve group information from AddEditGroupPage
                String groupPhoto = data.getStringExtra(Common.GROUP_PHOTO);
                String groupName = data.getStringExtra(Common.GROUP_NAME);
                ArrayList<String> groupMembers = data.getStringArrayListExtra(Common.GROUP_MEMBERS);

                //Add fields to group object
                Group group = new Group(groupPhoto, groupName, groupMembers);
                group.setId(groupId); //Pass in primary key so database can identify which group to update
                groupViewModel = new ViewModelProvider(this).get(GroupViewModel.class);
                groupViewModel.updateGroup(group);

                //Display toast informing user that changes to contact have been saved.
                Toast.makeText(this, "Group updated", Toast.LENGTH_SHORT).show();

                //Return to GroupList
                Intent openGroupListIntent = new Intent(this, GroupList.class);
                startActivity(openGroupListIntent);
            }
        }
    }
}
