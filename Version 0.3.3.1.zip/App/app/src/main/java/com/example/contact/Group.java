package com.example.contact;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Group
{
    private @PrimaryKey @NonNull String id;

    @NonNull
    public String getId()
    {
        return id;
    }
    @NonNull
    public void setId(String id)
    {
        this.id = id;
    }
}
