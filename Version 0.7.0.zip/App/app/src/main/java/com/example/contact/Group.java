package com.example.contact;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

import java.util.ArrayList;

@Entity
@TypeConverters({Converters.class})
public class Group
{
    @PrimaryKey(autoGenerate = true)
    private int id;

    private String groupImagePath;
    private String groupName;
    private ArrayList<Contact> groupMembers; //Holds ID(s) of Contact(s) in Group

    public Group(String groupImagePath, String groupName, ArrayList<Contact> groupMembers)
    {
        this.groupImagePath = groupImagePath;
        this.groupName = groupName;
        this.groupMembers = groupMembers;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public int getId()
    {
        return id;
    }

    public void setGroupImagePath(String groupImagePath) { this.groupImagePath = groupImagePath; }

    public String getGroupImagePath()
    {
        return groupImagePath;
    }

    public void setGroupName(String groupName) {this.groupName = groupName;}

    public String getGroupName()
    {
        return groupName;
    }

    public void setGroupMembers(ArrayList<Contact> groupMembers){this.groupMembers = groupMembers; }

    public ArrayList<Contact> getGroupMembers(){return groupMembers; }
}
