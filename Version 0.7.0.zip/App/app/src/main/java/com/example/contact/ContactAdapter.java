package com.example.contact;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.amulyakhare.textdrawable.TextDrawable;
import com.amulyakhare.textdrawable.util.ColorGenerator;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

/*
Allows you to enter list of Contacts into RecycleView
ContactAdapter.contactHolder is passed in so the RecyclerView Adapter knows this is the view holder we want to use
 */
public class ContactAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>
{
    private List<Contact> contacts = new ArrayList<>();
    private List<Contact> contactsCopy = new ArrayList<>(); //Compare with contacts for search
    private OnItemClickListener listener;

    @NonNull
    @Override //Where you create and return a contact holder
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType)
    {
        //Parent is the ViewGroup parameter in the method. This is the RecyclerView
        LayoutInflater inflater = LayoutInflater.from(viewGroup.getContext());

        if (contactsCopy.size() == 0)
        {
            contactsCopy.addAll(contacts);
        }

        if(viewType == Common.VIEWTYPE_CONTACT)
        {
            ViewGroup contactView = (ViewGroup)inflater.inflate(R.layout.contact_item, viewGroup, false);
            ContactViewHolder contactViewHolder = new ContactViewHolder(contactView);
            return contactViewHolder;
        }
        else if(viewType == Common.VIEWTYPE_LETTER) //If viewType is alphabet
        {
            ViewGroup letterView = (ViewGroup)inflater.inflate(R.layout.letter_item, viewGroup, false);
            LetterViewHolder letterViewHolder = new LetterViewHolder(letterView);
            return letterViewHolder;
        }
        else //If viewType is neither contact nor alphabet (which it should never be), return letterViewHolder
        {
            ViewGroup letterView = (ViewGroup)inflater.inflate(R.layout.letter_item, viewGroup, false);
            LetterViewHolder letterViewHolder = new LetterViewHolder(letterView);
            return letterViewHolder;
        }
    }


    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int position)
    {
        //This is where we pull data from each Contact object and put it into the views of the ContactHolder
        if(viewHolder instanceof ContactViewHolder)
        {
            ContactViewHolder contactViewHolder = (ContactViewHolder) viewHolder;
            Contact currentContact = contacts.get(position);

            //Set card name equal to contact name
            if(currentContact.getName() != null && !currentContact.getName().isEmpty()) //If name was entered for contact
            {
                contactViewHolder.contactName.setText(currentContact.getName()); //Set name equal to contact name
            }
            else //If no name was entered for contact
            {
                contactViewHolder.contactName.setText(R.string.unknown_name);
            }

            //Set card number equal to number entered
            if(currentContact.getMobileNumber() != null && !currentContact.getMobileNumber().isEmpty()) //If mobile number was entered for contact
            {
                contactViewHolder.contactNumber.setText(currentContact.getMobileNumber()); //Set number equal to mobile
            }
            else if(currentContact.getHomeNumber() != null && !currentContact.getHomeNumber().isEmpty()) //If mobile number is null but home number was entered for contact
            {
                contactViewHolder.contactNumber.setText(currentContact.getHomeNumber()); //Set number equal to home
            }
            else if(currentContact.getWorkNumber() != null && !currentContact.getWorkNumber().isEmpty()) //If mobile and home number is null but work number was entered for contact
            {
                contactViewHolder.contactNumber.setText(currentContact.getWorkNumber()); //Set number equal to work
            }
            else //If no number was entered for mobile nor home nor work
            {
                contactViewHolder.contactNumber.setText(R.string.unknown_number);
            }

            //Set card photo equal to contact photo
            if(currentContact.getContactImagePath() != null && !currentContact.getContactImagePath().isEmpty()) //If image was selected for contact
            {
                try //If there is no error in getting file, convert to bitmap and set ImageViewer to display it
                {
                    Bitmap selectedImage = BitmapFactory.decodeStream(new FileInputStream(new File(currentContact.getContactImagePath())));
                    contactViewHolder.contactPhoto.setImageBitmap(selectedImage); //Set photo to selected image
                }
                catch(FileNotFoundException e) //If there is an error in displaying file, check for username and set image to first letter of name
                {
                    e.printStackTrace();

                    //Check for username. If one exists, set image to first letter.
                    if(currentContact.getName() != null && !currentContact.getName().isEmpty())
                    {
                        ColorGenerator generator = ColorGenerator.MATERIAL;
                        TextDrawable drawable = TextDrawable
                                .builder()
                                .beginConfig()
                                .width(96)
                                .height(96)
                                .endConfig()
                                .buildRound(String.valueOf(currentContact.getName().charAt(0)), generator.getRandomColor());
                        contactViewHolder.contactPhoto.setImageDrawable(drawable);
                    }
                    else //If no username or email address, set to default user image
                    {
                        contactViewHolder.contactPhoto.setImageResource(R.drawable.ic_user); //Set photo to default image
                    }
                }
            }
            else //If no image was selected
            {
                //Check for username. If one exists, set image to first letter.
                if(currentContact.getName() != null && !currentContact.getName().isEmpty())
                {
                    ColorGenerator generator = ColorGenerator.MATERIAL;
                    TextDrawable drawable = TextDrawable
                            .builder()
                            .beginConfig()
                            .width(96)
                            .height(96)
                            .endConfig()
                            .buildRound(String.valueOf(currentContact.getName().charAt(0)), generator.getRandomColor());
                    contactViewHolder.contactPhoto.setImageDrawable(drawable);
                }
                else //If no username or email address, set to default user image
                {
                    contactViewHolder.contactPhoto.setImageResource(R.drawable.ic_user); //Set photo to default image
                }

            }
        }
        else if(viewHolder instanceof LetterViewHolder)
        {
            LetterViewHolder alphabetViewHolder = (LetterViewHolder) viewHolder;

            if(contacts.get(position).getName() != null && !contacts.get(position).getName().isEmpty())
            {
                alphabetViewHolder.letter.setText(contacts.get(position).getName().toUpperCase()); //Name. Later on the first letter of the name will be taken for the header
            }
            else
            {
                alphabetViewHolder.letter.setText("#"); //If name is null, set header to #
            }
        }
    }

    @Override
    public int getItemViewType(int position)
    {
        return contacts.get(position).getViewType(); //Used to determine if view selected is contact or alphabet character
    }

    @Override
    public int getItemCount() //Returns how many items we want to display in RecycleView
    {
        return contacts.size(); //Display as many items as there are contacts
    }

    public Contact getContactAt(int position) //Return contact at specified position in list
    {
        return contacts.get(position);
    }

    public void setContacts(List<Contact> contacts) //Get all Contacts and pass to local list that is used to display them in RecycleView
    {
        this.contacts = contacts;
        notifyDataSetChanged(); //Tells Adapter to redraw layout
    }

    //Nested Class - Holds Views for RecycleView layout
    public class ContactViewHolder extends RecyclerView.ViewHolder
    {
        private TextView contactName;
        private TextView contactNumber;
        private ImageView contactPhoto;

        //Background (Delete animation) and Foreground (Contact info)
        public RelativeLayout viewBackground;
        public RelativeLayout viewForeground;


        //ItemView represents the card
        public ContactViewHolder(@NonNull View itemView)
        {
            super(itemView);
            //Items inside the card
            contactName = itemView.findViewById(R.id.contact_card_name);
            contactNumber = itemView.findViewById(R.id.contact_card_number);
            contactPhoto = itemView.findViewById(R.id.contact_card_photo);

            //The foreground and background of the card
            viewBackground = itemView.findViewById(R.id.view_background);
            viewForeground = itemView.findViewById(R.id.view_foreground);

            //Carry out instructions when contact card in list is clicked
            itemView.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View view)
                {
                    int position = getAdapterPosition(); //Pass position of clicked card

                    //Make sure item with invalid position is not clicked
                    //Possible if deleted item that is in the animation of behind deleted is clicked on
                    if(listener != null && position != RecyclerView.NO_POSITION)
                    {
                        listener.onItemClick(contacts.get(position)); //Get contact object that corresponds to card that was clicked
                    }
                }
            });
        }
    }

    public class LetterViewHolder extends RecyclerView.ViewHolder
    {
        TextView letter;
        public LetterViewHolder(@NonNull View itemView)
        {
            super(itemView);
            letter = itemView.findViewById(R.id.letter);
        }
    }

    //Filter contacts displayed during search
    public void filter(String text)
    {
        contacts.clear();
        if(text.isEmpty())
        {
            contacts.addAll(contactsCopy);
        }
        else
        {
            text = text.toLowerCase();
            for(Contact item: contactsCopy)
            {
                if((item.getName() != null && !item.getName().isEmpty() && item.getName().toLowerCase().contains(text)))
                {
                    contacts.add(item);
                }
            }
        }
        notifyDataSetChanged();
    }


    public interface OnItemClickListener
    {
        void onItemClick(Contact contact);
    }

    public void setOnItemClickListener(OnItemClickListener listener)
    {
        this.listener = listener;
    }
}
