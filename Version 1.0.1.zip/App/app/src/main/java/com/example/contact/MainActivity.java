package com.example.contact;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.DialogFragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.SearchView;
import android.widget.Toast;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;

public class MainActivity extends AppCompatActivity implements RecyclerItemTouchHelper.RecyclerItemTouchHelperListener
{
    private ContactViewModel contactViewModel;

    private List<Contact> contactsSorted; //List of contacts and letter headers to be displayed
    private RecyclerView recyclerView;

    private SearchView searchView;

    private static final String USER_PHOTO = "com.example.contact.USER_PHOTO";

    private CoordinatorLayout mainActivityLayout;

    private ContactAdapter contactAdapter;


    //-----------------------------------OnCreate-----------------------------------//
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Contacts");

        //Layout
        mainActivityLayout = findViewById(R.id.mainActivityLayout);

        //Add Button
        FloatingActionButton addContactButton = findViewById(R.id.addContactButton);

        //Pop up with type of contact to add
        addContactButton.setOnClickListener(new View.OnClickListener() //Called when button is pressed
        {
            @Override
            public void onClick(View view) //When button is pressed, open ContactDialog activity and choose type of contact
            {
                // User touched the dialog's regular button
                Intent intent = new Intent(MainActivity.this, AddEditContact.class);
                startActivityForResult(intent, Common.ADD_CONTACT_REQUEST);
            }
        });

        setUserPhoto(); //Set image to selected image, if it exists

        //Set up RecycleView
        recyclerView = findViewById(R.id.contact_list);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager); //Every RecyclerView needs a layout manager
        recyclerView.addItemDecoration(new DividerItemDecoration(this, layoutManager.getOrientation()));
        recyclerView.setHasFixedSize(true);


        contactAdapter = new ContactAdapter();
        recyclerView.setAdapter(contactAdapter); //Populate RecyclerView with list of contacts in adapter

        //Gain access to ContactViewModel
        contactViewModel = new ViewModelProvider(this).get(ContactViewModel.class);

        //If activity is in foreground and list of contacts have changed, update RecyclerView
        contactViewModel.getAllContacts().observe(this, new Observer<List<Contact>>()
        {
            @Override
            public void onChanged(List<Contact> contacts) //Updates RecyclerView whenever there is a change in the list of contacts
            {
                //Sort contacts
                contactsSorted = Common.sortContactList(contacts);
                //Add letter headers to list
                contactsSorted = Common.addAlphabetsContact(contactsSorted);
                contactAdapter.setContacts(contactsSorted);
            }
        });

        contactAdapter.setOnItemClickListener(new ContactAdapter.OnItemClickListener()
        {
            @Override
            public void onItemClick(Contact contact)
            {
                //Open Contact Page Activity (where contact can be edited or deleted)

                Intent intent = new Intent(MainActivity.this, ContactPage.class);

                //Pass data from contact object to ContactPage
                intent.putExtra(Common.CONTACT_ID, contact.getId()); //Pass to AddEditContact to later pass back to MainActivity in order to tell database what contact to update
                intent.putExtra(Common.CONTACT_USERNAME, contact.getName());
                intent.putExtra(Common.CONTACT_PHOTO, contact.getContactImagePath());
                intent.putExtra(Common.CONTACT_MOBILE, contact.getMobileNumber());
                intent.putExtra(Common.CONTACT_HOME, contact.getHomeNumber());
                intent.putExtra(Common.CONTACT_WORK, contact.getWorkNumber());
                intent.putExtra(Common.CONTACT_EMAIL, contact.getEmailAddress());
                intent.putExtra(Common.CONTACT_ADDRESS, contact.getAddress());
                intent.putExtra(Common.CONTACT_BLACKLISTED, contact.getBlacklisted());

                startActivity(intent);
            }
        });

        ItemTouchHelper.SimpleCallback itemTouchHelperCallback = new RecyclerItemTouchHelper(0, ItemTouchHelper.LEFT, this);
        new ItemTouchHelper(itemTouchHelperCallback).attachToRecyclerView(recyclerView);
    } //End of OnCreate function

    @Override
    public boolean onCreateOptionsMenu(Menu menu) //Put SearchView in menu
    {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.contact_menu, menu); //Set contact_menu to menu of activity

        MenuItem searchContact = menu.findItem(R.id.action_search_contact);
        SearchView searchViewContact = (SearchView) searchContact.getActionView();

        searchViewContact.setOnQueryTextListener(new SearchView.OnQueryTextListener()
        {
            @Override
            public boolean onQueryTextSubmit(String query)
            {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) //Used to filter contact list in realtime
            {
                contactAdapter.getFilter().filter(newText); //Pass in text user entered in their search
                return false;
            }
        });
        return true;
    }

    public void viewGroupsButtonPressed(View view) //Display all groups in GroupList activity
    {
        Intent intent = new Intent(MainActivity.this, GroupList.class);
        startActivity(intent);
    }

    //-----------------------------------Display User Photo-----------------------------------//
    private void setUserPhoto()
    {
        ImageView ownerPhoto = findViewById(R.id.userPhoto);
        File file = new File(getApplicationContext().getFilesDir().getParent() + "/app_imageDir/" + USER_PHOTO + ".jpg");

        if(!file.exists()) //If file does not exist, meaning user never selected image for themselves
        {
            ownerPhoto.setImageResource(R.drawable.ic_user);
        }
        else //If file exists, set photo to selected image
        {
            try //Get image
            {
                Bitmap selectedImage = BitmapFactory.decodeStream(new FileInputStream(file));
                ownerPhoto.setImageBitmap(selectedImage);
            }
            catch(FileNotFoundException e) //If there was an error getting image, set image to default user photo
            {
                ownerPhoto.setImageResource(R.drawable.ic_user);
            }
        }
    }

    //-----------------------------------Listeners-----------------------------------//

    //When user clicks on image for user, allow them to upload picture form phone
    public void userPhotoClicked(View view)
    {
        imagePicker();
    }

    private void imagePicker()
    {
        if(ActivityCompat.checkSelfPermission(this, READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)
        {
            //Step 1: Create Intent
            // (ACTION_GET_CONTENT allows user to select particular kind of data and return it)
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);

            //Step 2: Set intent type
            // (This indicates the type of data the intent wants returned to it)
            intent.setType("image/*");

            //Extras (Elaborate on what this does)
            intent.putExtra("crop", "true");
            intent.putExtra("scale", true);
            intent.putExtra("aspectX", 16);
            intent.putExtra("aspectY", 9);

            //Step 4: Call startActivityForResult method
            // (Starts another activity and receives a result back from it)
            startActivityForResult(intent, Common.PICK_IMAGE_REQUEST_CODE);
        }
        else
        {
            String permissions[] = {READ_EXTERNAL_STORAGE};
            ActivityCompat.requestPermissions(this, permissions, Common.READ_EXTERNAL_STORAGE_REQUEST_CODE);
        }
    }

    //Callback when recycler view is swiped.
    @Override
    public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction, int position)
    {
        if (viewHolder instanceof ContactAdapter.ContactViewHolder)
        {
            //Delete contact
            contactViewModel.deleteContact(contactAdapter.getContactAt(viewHolder.getAdapterPosition()));
            //Display toast confirming to user that contact has been deleted
            Toast.makeText(MainActivity.this, "Contact has been deleted", Toast.LENGTH_SHORT).show();
        }
    }

    //-----------------------------------Permissions-----------------------------------//
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        //Implements functionality for when request codes are sent

        //If requestCode to select picture is sent and there is no error
        if(requestCode == Common.PICK_IMAGE_REQUEST_CODE)
        {
            if(resultCode == RESULT_OK)
            {
                //Get Uri of selected image and set user photo to it
                Uri uri = data.getData();
                if(uri != null)
                {
                    ImageView userPhoto = findViewById(R.id.userPhoto);
                    userPhoto.setImageURI(uri);

                    //Save selected photo and display when app is opened again
                    ImageDecoder.Source source = ImageDecoder.createSource(this.getContentResolver(), data.getData()); //Uri -> Bitmap
                    try
                    {
                        Bitmap imageBitmap = ImageDecoder.decodeBitmap(source);
                        //Save image with random name to avoid duplicate names
                        String x = new ImageSaver(imageBitmap, getApplicationContext(), USER_PHOTO).saveToInternalStorage();
                        Log.d("File Path", x);
                    }
                    catch(IOException e)
                    {
                        e.printStackTrace();
                    }
                }
            }
            else
            {
                Toast.makeText(this, "Error. Need permission to access photos", Toast.LENGTH_SHORT);
            }
        }

        //If requestCode to add contact is sent and there is no error
        if(requestCode == Common.ADD_CONTACT_REQUEST)
        {
            if(resultCode == RESULT_OK)
            {
                //Retrieve contact information from AddEditContact page
                String contactPhoto = data.getStringExtra(Common.CONTACT_PHOTO);
                String userName = data.getStringExtra(Common.CONTACT_USERNAME);
                String cellNum = data.getStringExtra(Common.CONTACT_MOBILE);
                String homeNum = data.getStringExtra(Common.CONTACT_HOME);
                String workNum = data.getStringExtra(Common.CONTACT_WORK);
                String email = data.getStringExtra(Common.CONTACT_EMAIL);
                String address = data.getStringExtra(Common.CONTACT_ADDRESS);


                //Add fields to contact object
                Contact contact = new Contact(contactPhoto, userName, cellNum, homeNum, workNum, email, address);
                //Add contact object to database
                contactViewModel.insertContact(contact);
                //Display toast informing user that contact was added.
                Toast.makeText(this, "Contact added", Toast.LENGTH_SHORT).show();
            }
            else //If there was an error in adding the contact
            {
                //Display toast informing user that contact was not added.
                Toast.makeText(this, "Error. Contact not added.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults)
    {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if(requestCode == Common.READ_EXTERNAL_STORAGE_REQUEST_CODE)
        {
            //If the user allows permission
            if(grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                imagePicker();
            }
        }
    }
} //End of MainActivity
