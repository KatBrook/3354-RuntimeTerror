package com.example.contact;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Group
{/*
    private @PrimaryKey @NonNull String id;

    @NonNull
    public String getId()
    {
        return id;
    }
    @NonNull
    public void setId(String id)
    {
        this.id = id;
    }
    */

    @PrimaryKey(autoGenerate = true)
    private int id;

    private String groupImagePath;
    private String groupName;
    private String groupMembers;

    public Group(String groupImagePath, String groupName, String groupMembers)
    {
        this.groupImagePath = groupImagePath;
        this.groupName = groupName;
        this.groupMembers = groupMembers;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public int getId()
    {
        return id;
    }

    public String getGroupImagePath()
    {
        return groupImagePath;
    }

    public String getGroupName()
    {
        return groupName;
    }

    public String getGroupMembers()
    {
        return groupMembers;
    }
}
