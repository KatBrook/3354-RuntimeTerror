package com.example.contact;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class GroupPage extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_page);
    }

    public void deleteGroupButtonPressed(View view)
    {

    }

    public void backButtonGroupPressed(View view)
    {
        Intent openMainActivityIntent = new Intent(this, GroupList.class);
        startActivity(openMainActivityIntent);
    }

}
