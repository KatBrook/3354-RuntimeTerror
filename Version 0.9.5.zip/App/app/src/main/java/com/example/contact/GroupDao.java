package com.example.contact;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;

import androidx.room.Query;
import androidx.room.Update;

import java.util.List;


/*
Room provides an abstraction layer over SQLite to allow fluent database access
SQLite is a local database that doesn't require internet access.
It saves its data into a text file and it's saved locally on the device
Android comes with SQLite database implementation built in

@Dao defines ContactDao interface as a data access object.
*/

@Dao
public interface GroupDao
{
    //@Query("select * FROM contact") //SQL Statement
    @Query("select * FROM `Group`") //SQL Statement

    LiveData<List<Group>> getAllGroups(); //Method carries out SQL Statement

    @Insert
    void insertGroup(Group group);

    @Update
    void updateGroup(Group group);

    @Delete
    void deleteGroup(Group group);
}
