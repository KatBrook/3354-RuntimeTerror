package com.example.contact;

import android.app.Application;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.sqlite.db.SupportSQLiteQuery;

import java.util.List;

/*
Store and preserve data for user interface and communicate with repository
ViewModels survive configuration changes (i.e. rotating device)
Extends AndroidViewModel which is a subclass of ViewModel.
In AndroidViewModel, you get passed application and constructor which you can use whenever application context is needed
In ViewModel, you can pass context needed for ContactDB
Activity should only have reference to ViewModel, not repository

Activity -> ViewModel -> Repository -> Database
 */
public class ContactViewModel extends AndroidViewModel
{
    private ContactRepository repository;
    private LiveData<List<Contact>> allContacts;

    public ContactViewModel(Application application)
    {
        super(application);
        repository = new ContactRepository(application);
        allContacts = repository.getAllContacts();
    }

    //Methods that activity will call in order to pass data to repository that will be stored in database
    public void insertContact(Contact contact)
    {
        repository.insertContact(contact);
    }

    public void updateContact(Contact contact)
    {
        repository.updateContact(contact);
    }

    public void deleteContact(Contact contact)
    {
        repository.deleteContact(contact);
    }

    public LiveData<List<Contact>> getAllContacts()
    {
        return allContacts;
    }
}
