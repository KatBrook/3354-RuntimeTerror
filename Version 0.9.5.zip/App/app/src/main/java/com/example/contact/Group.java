package com.example.contact;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

import java.util.ArrayList;
import java.util.UUID;

@Entity
@TypeConverters({Converters.class})
public class Group
{
    @PrimaryKey
    @NonNull
    private String id = UUID.randomUUID().toString();

    private String groupImagePath;
    private String groupName;
    private ArrayList<String> groupMembers; //Holds ID(s) of Contact(s) in Group

    private int viewTypeGroup = Common.VIEWTYPE_GROUP; //Have default be contact

    //For creating letters for groups
    @Ignore //Tell Room Database to ignore this constructor
    public Group(String groupName, int viewTypeGroup)
    {
        this.groupName = groupName;
        setViewTypeGroup(viewTypeGroup);
    }
    //For creating groups
    public Group(String groupImagePath, String groupName, ArrayList<String> groupMembers)
    {
        this.groupImagePath = groupImagePath;
        this.groupName = groupName;
        this.groupMembers = groupMembers;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getId()
    {
        return id;
    }

    public String getGroupImagePath() { return groupImagePath; }

    public String getGroupName()
    {
        if(groupName != null && !groupName.isEmpty() && !groupName.trim().isEmpty())
        {
            return groupName;
        }
        else
        {
            return "Unknown Name";
        }
    }

    public ArrayList<String> getGroupMembers(){return groupMembers; }

    public int getViewTypeGroup()
    {
        return viewTypeGroup;
    }

    public void setViewTypeGroup(int viewTypeGroup) { this.viewTypeGroup = viewTypeGroup; }
}
