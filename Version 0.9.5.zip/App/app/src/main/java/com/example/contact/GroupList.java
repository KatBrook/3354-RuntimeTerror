package com.example.contact;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

//Shows all groups
public class GroupList extends AppCompatActivity implements RecyclerItemTouchHelper.RecyclerItemTouchHelperListener
{
    private GroupAdapter groupAdapter;
    private GroupViewModel groupViewModel;
    List<Group> groupsSorted;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_groups);
        setTitle("Groups"); //Set title of Activity Bar

        FloatingActionButton addGroupButton = findViewById(R.id.addGroupButton);
        addGroupButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(GroupList.this, AddGroupPage.class); //Go to group page to create a group and the members inside
                startActivityForResult(intent, Common.ADD_GROUP_REQUEST);
            }
        });

        RecyclerView recyclerGroupView = findViewById(R.id.group_list);
        recyclerGroupView.setLayoutManager(new LinearLayoutManager(this)); //Every RecyclerView needs a layout manager
        recyclerGroupView.setHasFixedSize(true);

        groupAdapter = new GroupAdapter();
        recyclerGroupView.setAdapter(groupAdapter); //Populate RecyclerView with list of Groups in adapter

        //Gain access to GroupViewModel

        groupViewModel = new ViewModelProvider(this).get(GroupViewModel.class);

        //If activity is in foreground and list of Groups have changed, update RecyclerView

        groupViewModel.getAllGroups().observe(this, new Observer<List<Group>>()
        {
            @Override
            public void onChanged(List<Group> groups)
            {
                //Updates RecyclerView whenever there is a change in the list of groups
                groupsSorted = Common.sortGroupList(groups);
                //Add letter headers to list
                groupsSorted = Common.addAlphabetsGroup(groupsSorted);
                groupAdapter.setGroups(groupsSorted);
            }
        });

        groupAdapter.setOnItemClickListener(new GroupAdapter.OnItemClickListener()
        {
            @Override
            public void onItemClick(Group group) //When group card is selected
            {
                //Open Group Page Activity (where Group can be edited or deleted)
                Intent intent = new Intent(GroupList.this, GroupPage.class);

                //Pass data from group object to AddEditGroup Activity for Editing
                intent.putExtra(Common.GROUP_ID, group.getId()); //Pass to GroupPage to later pass back to MainActivity in order to tell database what Group to update
                intent.putExtra(Common.GROUP_NAME, group.getGroupName());
                intent.putExtra(Common.GROUP_PHOTO, group.getGroupImagePath());
                intent.putExtra(Common.GROUP_MEMBERS, group.getGroupMembers());
                startActivity(intent);
            }
        });

        ItemTouchHelper.SimpleCallback itemTouchHelperCallbackGroup = new RecyclerItemTouchHelper(0, ItemTouchHelper.LEFT, this);
        new ItemTouchHelper(itemTouchHelperCallbackGroup).attachToRecyclerView(recyclerGroupView);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) //Put SearchView in menu
    {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.group_menu, menu); //Set group_menu to menu of activity

        MenuItem searchGroup = menu.findItem(R.id.action_search_group);
        SearchView searchViewGroup = (SearchView) searchGroup.getActionView();

        searchViewGroup.setOnQueryTextListener(new SearchView.OnQueryTextListener()
        {
            @Override
            public boolean onQueryTextSubmit(String query)
            {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) //Used to filter group list in realtime
            {
                groupAdapter.getFilter().filter(newText); //Pass in text user entered in their search
                return false;
            }
        });
       return true;
    }

    //Callback when recycler view is swiped.
    @Override
    public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction, int position)
    {
        if (viewHolder instanceof GroupAdapter.GroupViewHolder)
        {
            //Delete Group
            groupViewModel.deleteGroup(groupAdapter.getGroupAt(viewHolder.getAdapterPosition()));
            //Display toast confirming to user that Group has been deleted
            Toast.makeText(GroupList.this, "Group has been deleted", Toast.LENGTH_SHORT).show();
        }
    }
}
