package com.example.contact;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

public class GroupPage extends AppCompatActivity
{
    //Group Data
    private String groupName;
    private String groupImageFilePath;
    private List<String> groupMemberIDs;

    //Group Page Fields
    TextView groupNameTextView;
    ImageView groupPhoto;

    //Tools to display contacts that make up group
    private ContactAdapter contactAdapter;
    private ContactViewModel contactViewModel;
    private RecyclerView recyclerView;
    private List<Contact> contactsSorted;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_page);
        setTitle("Group Information"); //Set title of toolbar for activity
        createIDs();

        //Get group information
        Intent intent = getIntent();
        if(intent != null)
        {
            groupName = intent.getStringExtra(Common.GROUP_NAME);
            groupImageFilePath = intent.getStringExtra(Common.GROUP_PHOTO);
            groupMemberIDs = intent.getStringArrayListExtra(Common.GROUP_MEMBERS);
        }


        displayGroupInformation();
        setPhoto();

        //Set up RecycleView
        recyclerView = findViewById(R.id.member_list);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager); //Every RecyclerView needs a layout manager
        recyclerView.addItemDecoration(new DividerItemDecoration(this, layoutManager.getOrientation()));
        recyclerView.setHasFixedSize(true);


        contactAdapter = new ContactAdapter();
        recyclerView.setAdapter(contactAdapter); //Populate RecyclerView with list of contacts in adapter

        //Gain access to ContactViewModel
        contactViewModel = new ViewModelProvider(this).get(ContactViewModel.class);

        //If activity is in foreground and list of contacts have changed, update RecyclerView
        contactViewModel.getAllContacts().observe(this, new Observer<List<Contact>>()
        {
            @Override
            public void onChanged(List<Contact> contacts) //Updates RecyclerView whenever there is a change in the list of contacts
            {
                //Sort contacts
                contactsSorted = Common.sortContactList(contacts);

                List<Contact> groupMembers = new ArrayList<>(); //Will hold contacts user selected to be in group

                //Go through all contacts and put contacts user selected as group members in groupMembers ArrayList
                for(int i = 0; i < contactsSorted.size(); i++)
                {
                    for(int j = 0; j < groupMemberIDs.size(); j++)
                    {
                        if(contactsSorted.get(i).getId().equals(groupMemberIDs.get(j)))
                        {
                            groupMembers.add(contactsSorted.get(i));
                        }
                    }
                }

                //Add letter headers to list
                groupMembers = Common.addAlphabetsContact(groupMembers);

                contactAdapter.setContacts(groupMembers);
            }
        });

        contactAdapter.setOnItemClickListener(new ContactAdapter.OnItemClickListener()
        {
            @Override
            public void onItemClick(Contact contact)
            {
                //Open Contact Page Activity (where contact can be edited or deleted)

                Intent intent = new Intent(GroupPage.this, ContactPage.class);

                //Pass data from contact object to ContactPage
                intent.putExtra(Common.CONTACT_ID, contact.getId()); //Pass to AddEditContact to later pass back to MainActivity in order to tell database what contact to update
                intent.putExtra(Common.CONTACT_USERNAME, contact.getName());
                intent.putExtra(Common.CONTACT_PHOTO, contact.getContactImagePath());
                intent.putExtra(Common.CONTACT_MOBILE, contact.getMobileNumber());
                intent.putExtra(Common.CONTACT_HOME, contact.getHomeNumber());
                intent.putExtra(Common.CONTACT_WORK, contact.getWorkNumber());
                intent.putExtra(Common.CONTACT_EMAIL, contact.getEmailAddress());
                intent.putExtra(Common.CONTACT_ADDRESS, contact.getAddress());
                intent.putExtra(Common.CONTACT_BLACKLISTED, contact.getBlacklisted());

                startActivity(intent);
            }
        });
    }

    public void deleteGroupButtonPressed(View view)
    {

    }

    public void createIDs()
    {
        groupNameTextView = findViewById(R.id.groupName);
        groupPhoto = findViewById(R.id.groupPhoto);
    }

    public void displayGroupInformation()
    {
        groupNameTextView.setText(groupName);
    }

    public void setPhoto()
    {
        if(groupImageFilePath != null) //If an image exists for the group
        {
            try //If there is no error in getting file, convert to bitmap and set ImageViewer to display it
            {
                Bitmap selectedImage = BitmapFactory.decodeStream(new FileInputStream(new File(groupImageFilePath)));
                groupPhoto.setImageBitmap(selectedImage);
            }
            catch(FileNotFoundException e) //If there is an error in displaying file, set photo to default image
            {
                e.printStackTrace();
                groupPhoto.setImageResource(R.drawable.ic_user);
            }
        }
        else //If no image was passed, since no image was ever selected for contact, set image to default user photo
        {
            groupPhoto.setImageResource(R.drawable.ic_user);
        }
    }
}
