package com.example.contact;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.amulyakhare.textdrawable.TextDrawable;

import java.util.List;

//Display Alphabet(A-Z) and #
public class AlphabetAdapter extends RecyclerView.Adapter<AlphabetAdapter.AlphabetViewHolder>
{
    private List<String> alphabetList;
    private OnAlphabetClickListener listener;

    public AlphabetAdapter()
    {
        this.alphabetList = Common.generateAlphabet(); //Create alphabet when constructor is called
    }

    @NonNull
    @Override
    public AlphabetViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType)
    {
        View itemView = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.alphabet_item, viewGroup, false);
        return new AlphabetViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull AlphabetViewHolder alphabetViewHolder, final int position)
    {
        TextDrawable drawable;
        //Get available position of character
        final int available_position = Common.alphabet_available.indexOf(alphabetList.get(position));
        if(available_position != -1) //If there is a contact that has a letter, make letter green
        {
            drawable = TextDrawable.builder().buildRound(alphabetList.get(position), Color.GREEN);
        }
        else //If no contacts start with a letter, make that letter grey
        {
            drawable = TextDrawable.builder().buildRound(alphabetList.get(position), Color.GRAY);
        }

        alphabetViewHolder.itemView.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                //When user clicks on letter , go to MainActivity and scroll to position of first contact with letter
                listener.onAlphabetClickListener(alphabetList.get(position), position);
            }
        });
    }

    @Override
    public int getItemCount()
    {
        return alphabetList.size();
    }

    public class AlphabetViewHolder extends RecyclerView.ViewHolder
    {
        ImageView alphabetAvatar;
        public AlphabetViewHolder(@NonNull View itemView)
        {
            super(itemView);
            alphabetAvatar = itemView.findViewById(R.id.alphabet_avatar);
        }
    }

    public interface OnAlphabetClickListener
    {
        void onAlphabetClickListener(String alphabet, int position);
    }

    public void setOnAlphabetClickListener(OnAlphabetClickListener listener)
    {
        this.listener = listener;
    }
}
