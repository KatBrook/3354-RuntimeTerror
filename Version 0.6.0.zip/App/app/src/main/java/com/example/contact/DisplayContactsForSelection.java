package com.example.contact;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

//Shows all contacts. User selects contact(s) they wish to add to their group
public class DisplayContactsForSelection extends AppCompatActivity implements RecyclerItemTouchHelper.RecyclerItemTouchHelperListener
{
    private ContactAdapter contactAdapter;
    private ContactViewModel contactViewModel;

    private List<Contact> contactsSorted; //List of contacts and letter headers to be displayed

    private Toolbar selectContactsToolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_contact_list);
        selectContactsToolbar = findViewById(R.id.display_selected_contacts_toolbar);
        selectContactsToolbar.setTitle("Select Contacts for Group");

        RecyclerView recyclerContactView = findViewById(R.id.contact_list);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerContactView.setLayoutManager(layoutManager); //Every RecyclerView needs a layout manager
        recyclerContactView.addItemDecoration(new DividerItemDecoration(this, layoutManager.getOrientation()));
        recyclerContactView.setHasFixedSize(true);


        contactAdapter = new ContactAdapter();
        recyclerContactView.setAdapter(contactAdapter); //Populate RecyclerView with list of contacts in adapter

        //Gain access to ContactViewModel
        contactViewModel = new ViewModelProvider(this).get(ContactViewModel.class);

        //If activity is in foreground and list of contacts have changed, update RecyclerView
        contactViewModel.getAllContacts().observe(this, new Observer<List<Contact>>()
        {
            @Override
            public void onChanged(List<Contact> contacts) //Updates RecyclerView whenever there is a change in the list of contacts
            {
                //Sort contacts
                contactsSorted = Common.sortList(contacts);
                //Add letter headers to list
                contactsSorted = Common.addAlphabets(contactsSorted);
                contactAdapter.setContacts(contactsSorted);
            }
        });


        //When a contact is clicked on add it to the group member list

        contactAdapter.setOnItemClickListener(new ContactAdapter.OnItemClickListener()
        {
            @Override
            public void onItemClick(Contact contact)
            {
                //User touched a contact to add
                Intent intent = new Intent(DisplayContactsForSelection.this, AddGroupPage.class); //When a contact is clicked, pass ID to group page

                intent.putExtra(Common.CONTACT_ID, contact.getId());
                startActivityForResult(intent, Common.ADD_GROUP_MEMBER_REQUEST);
            }
        });

        ItemTouchHelper.SimpleCallback itemTouchHelperCallbackContact = new RecyclerItemTouchHelper(0, ItemTouchHelper.LEFT, this);
        new ItemTouchHelper(itemTouchHelperCallbackContact).attachToRecyclerView(recyclerContactView);
    }
    //Callback when recycler view is swiped.
    @Override
    public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction, int position)
    {
        if (viewHolder instanceof ContactAdapter.ContactViewHolder)
        {
            //Delete contact
            contactViewModel.deleteContact(contactAdapter.getContactAt(viewHolder.getAdapterPosition()));
            //Display toast confirming to user that contact has been deleted
            Toast.makeText(DisplayContactsForSelection.this, "Contact has been deleted", Toast.LENGTH_SHORT).show();
        }
    }
}
