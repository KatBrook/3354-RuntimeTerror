package com.example.contact;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatDialogFragment;
import androidx.fragment.app.DialogFragment;

import com.google.android.material.floatingactionbutton.FloatingActionButton;


//This class is for creating a popup/dialog that lets the user to choose teh type of contact they want to add: regular or group

public class ContactDialog extends DialogFragment
{
    String[] contactArray = new String[] {"Regular Contact", "Group Contact", "Cancel"};


    /* The activity that creates an instance of this dialog fragment must
     * implement this interface in order to receive event callbacks.
     * Each method passes the DialogFragment in case the host needs to query it. */
    public interface NoticeDialogListener
    {
        public void onDialogPositiveClick(DialogFragment dialog);
        public void onDialogNeutralClick(DialogFragment dialog);
        public void onDialogNegativeClick(DialogFragment dialog);
    }

    // Use this instance of the interface to deliver action events
    NoticeDialogListener listener;

    // Override the Fragment.onAttach() method to instantiate the NoticeDialogListener
    @Override
    public void onAttach(Context context)
    {
        super.onAttach(context);
        // Verify that the host activity implements the callback interface
        try
        {
            // Instantiate the NoticeDialogListener so we can send events to the host
            listener = (NoticeDialogListener) context;
        }
        catch (ClassCastException e)
        {
            // The activity doesn't implement the interface, throw exception
            throw new ClassCastException(getActivity().toString()
                    + " must implement NoticeDialogListener");
        }
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState)
    {

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        //Create actual dialog

        //builder.setTitle("");
        builder.setTitle("What type of contact do you want to add?");

        builder.setItems(contactArray, new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
                //The which argument contains the index position of the selected item

                switch (which)
                {
                    case 0: // regular
                        //Send the positive button event back to the host activity
                        listener.onDialogPositiveClick(ContactDialog.this);
                        break;
                    case 1: // group
                        //Send the positive button event back to the host activity
                        listener.onDialogNeutralClick(ContactDialog.this);
                        break;
                    case 2: // cancel
                        //Send the positive button event back to the host activity
                        listener.onDialogNegativeClick(ContactDialog.this);
                        break;
                }
            }
        });

        //Return the created dialog

        return builder.create();
    }
}
