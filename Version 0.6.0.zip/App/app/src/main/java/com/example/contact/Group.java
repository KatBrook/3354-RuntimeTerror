package com.example.contact;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

import java.util.ArrayList;

@Entity
@TypeConverters({Converters.class})
public class Group
{/*
    private @PrimaryKey @NonNull String id;

    @NonNull
    public String getId()
    {
        return id;
    }
    @NonNull
    public void setId(String id)
    {
        this.id = id;
    }
    */

    @PrimaryKey(autoGenerate = true)
    private int id;

    private String groupImagePath;
    private String groupName;
    private ArrayList<Integer> groupMembers; //Holds ID(s) of Contact(s) in Group

    public Group(String groupImagePath, String groupName, ArrayList<Integer> groupMembers)
    {
        this.groupImagePath = groupImagePath;
        this.groupName = groupName;
        this.groupMembers = groupMembers;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public int getId()
    {
        return id;
    }

    public void setGroupImagePath(String groupImagePath) { this.groupImagePath = groupImagePath; }

    public String getGroupImagePath()
    {
        return groupImagePath;
    }

    public void setGroupName(String groupName) {this.groupName = groupName;}

    public String getGroupName()
    {
        return groupName;
    }

    public void setGroupMembers(ArrayList<Integer> groupMembers){this.groupMembers = groupMembers; }

    public ArrayList<Integer> getGroupMembers(){return groupMembers; }
}
