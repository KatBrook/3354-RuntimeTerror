package com.example.contact;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

/*
Allows you to enter list of Contacts into RecycleView
ContactAdapter.contactHolder is passed in so the RecyclerView Adapter knows this is the view holder we want to use
 */
public class GroupAdapter extends RecyclerView.Adapter<GroupAdapter.GroupViewHolder>
{
    private List<Group> groups = new ArrayList<>();
    private OnItemClickListener listener;

    @NonNull
    @Override //Where you create and return a contact holder
    public GroupViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        //Parent is the ViewGroup parameter in the method. This is the RecyclerView
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.group_item, parent, false);
        return new GroupViewHolder(itemView);
    }

    @Override //This is where we pull data from each Contact object and put it into the views of the ContactHolder
    public void onBindViewHolder(@NonNull GroupViewHolder holder, int position)
    {
        Group currentGroup = groups.get(position);

        //Set card name equal to contact name
        if(currentGroup.getGroupName() != null && !currentGroup.getGroupName().isEmpty()) //If name was entered for contact
        {
            holder.groupName.setText(currentGroup.getGroupName()); //Set name equal to contact name
        }
        else //If no name was entered for contact
        {
            holder.groupName.setText("No Group Name");
        }

        //Set card photo equal to contact photo
        if(currentGroup.getGroupImagePath() != null && !currentGroup.getGroupImagePath().isEmpty()) //If image was selected for contact
        {
            try //If there is no error in getting file, convert to bitmap and set ImageViewer to display it
            {
                Bitmap selectedImage = BitmapFactory.decodeStream(new FileInputStream(new File(currentGroup.getGroupImagePath())));
                holder.groupPhoto.setImageBitmap(selectedImage); //Set photo to selected image
            }
            catch(FileNotFoundException e) //If there is an error in displaying file, set photo to default image
            {
                e.printStackTrace();
                holder.groupPhoto.setImageResource(R.drawable.ic_user); //Set photo to default image
            }
        }
        else //If no image was selected
        {
            holder.groupPhoto.setImageResource(R.drawable.ic_user); //Set photo to default image
        }
    }

    @Override
    public int getItemCount() //Returns how many items we want to display in RecycleView
    {
        return groups.size(); //Display as many items as there are contacts
    }

    public Group getGroupAt(int position) //Return contact at specified position in list
    {
        return groups.get(position);
    }

    public void setGroups(List<Group> groups) //Get all Contacts and pass to local list that is used to display them in RecycleView
    {
        this.groups = groups;
        notifyDataSetChanged(); //Tells Adapter to redraw layout (CHANGE LATER ON)
    }

    //Nested Class - Holds Views for RecycleView layout
    class GroupViewHolder extends RecyclerView.ViewHolder
    {
        private TextView groupName;
        //private TextView groupMembers;
        private ImageView groupPhoto;

        //Background (Delete animation) and Foreground (Contact info)
        public RelativeLayout viewBackground;
        public RelativeLayout viewForeground;


        //ItemView represents the card
        public GroupViewHolder(@NonNull View itemView)
        {
            super(itemView);
            //Items inside the card
            groupName = itemView.findViewById(R.id.group_card_name);
            //groupMembers = itemView.findViewById(R.id.group_card_number);
            groupPhoto = itemView.findViewById(R.id.group_card_photo);

            //The foreground and background of the card
            viewBackground = itemView.findViewById(R.id.view_background);
            viewForeground = itemView.findViewById(R.id.view_foreground);

            //Carry out instructions when contact card in list is clicked
            itemView.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View view)
                {
                    int position = getAdapterPosition(); //Pass position of clicked card

                    //Make sure item with invalid position is not clicked
                    //Possible if deleted item that is in the animation of behind deleted is clicked on
                    if(listener != null && position != RecyclerView.NO_POSITION)
                    {
                        listener.onItemClick(groups.get(position)); //Get contact object that corresponds to card that was clicked
                    }
                }
            });
        }
    }


    public interface OnItemClickListener
    {
        void onItemClick(Group group);
    }

    public void setOnItemClickListener(OnItemClickListener listener)
    {
        this.listener = listener;
    }
}
