package com.example.contact;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.RawQuery;
import androidx.room.Update;
import androidx.sqlite.db.SupportSQLiteQuery;

import java.util.List;


/*
Room provides an abstraction layer over SQLite to allow fluent database access
SQLite is a local database that doesn't require internet access.
It saves its data into a text file and it's saved locally on the device
Android comes with SQLite database implementation built in

@Dao defines ContactDao interface as a data access object.
*/


@Dao
public interface ContactDao
{
    @Query("select * FROM contact") //SQL Statement
    LiveData<List<Contact>> getAllContacts(); //Method carries out SQL Statement

    @Query("select * FROM contact WHERE id=:id")
    Contact getContactById(String id);

    @Insert
    void insertContact(Contact contact);

    @Update
    void updateContact(Contact contact);

    @Delete
    void deleteContact(Contact contact);
}
