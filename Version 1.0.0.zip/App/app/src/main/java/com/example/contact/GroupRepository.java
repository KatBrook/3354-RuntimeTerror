package com.example.contact;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.List;

/*
Provides abstraction layer between Room database and app
Instead of user calling database and having to make async task calls every time,
this class is called instead which performs the calls for the user.
*/
public class GroupRepository
{
    //LiveData lets components in your app (usually the UI) observe LiveData objects for changes
    //private ContactDao contactDao;
    private GroupDao groupDao;
    private LiveData<List<Group>> allGroups;

    //Application (subclass of context) is passed in to use as context for database instance
    public GroupRepository(Application application)
    {
        ContactDB database = ContactDB.getInstance(application);

        //Set groupDao object equal to instance of database
        groupDao = database.groupDao();

        allGroups = groupDao.getAllGroups();
    }

    //These are the methods that make up the API which the repository exposes to the outside
    public void insertGroup(Group group)
    {
        new InsertGroupAsyncTask(groupDao).execute(group);
    }

    public void updateGroup(Group group)
    {
        new UpdateGroupAsyncTask(groupDao).execute(group);
    }

    public void deleteGroup(Group group)
    {
        new DeleteGroupAsyncTask(groupDao).execute(group);
    }

    public LiveData<List<Group>> getAllGroups()
    {
        return allGroups;
    }
    //--------------------------------------------------------------------------------

    //Room doesn't allow operations on main thread. AsycTask creates background thread
    private static class InsertGroupAsyncTask extends AsyncTask<Group, Void, Void>
    {
        private GroupDao groupDao;

        private InsertGroupAsyncTask(GroupDao groupDao)
        {
            this.groupDao = groupDao;
        }

        //The dots are called "Vargas." This is for methods that need to take a variable number (0 to n) of arguments
        @Override
        protected Void doInBackground(Group... groups)
        {
            //0 because only one contact is being passed in, at index 0
            groupDao.insertGroup(groups[0]);
            return null;
        }
    }

    private static class UpdateGroupAsyncTask extends AsyncTask<Group, Void, Void>
    {
        private GroupDao groupDao;

        private UpdateGroupAsyncTask(GroupDao groupDao)
        {
            this.groupDao = groupDao;
        }

        //The dots are called "Vargas." This is for methods that need to take a variable number (0 to n) of arguments
        @Override
        protected Void doInBackground(Group... groups)
        {
            //0 because only one contact is being passed in, at index 0
            groupDao.updateGroup(groups[0]);
            return null;
        }
    }

    private static class DeleteGroupAsyncTask extends AsyncTask<Group, Void, Void>
    {
        private GroupDao groupDao;

        private DeleteGroupAsyncTask(GroupDao groupDao)
        {
            this.groupDao = groupDao;
        }

        //The dots are called "Vargas." This is for methods that need to take a variable number (0 to n) of arguments
        @Override
        protected Void doInBackground(Group... groups)
        {
            //0 because only one contact is being passed in, at index 0
            groupDao.deleteGroup(groups[0]);
            return null;
        }
    }

}
