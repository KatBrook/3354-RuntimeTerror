package com.ram.calltext;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private final int MY_CALL_REQUEST = 1;
    private  final int MY_TEXT_SEND_REQUEST = 1;
    Contact con = new Contact();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );

        findViewById( R.id.btnStartPhoneCall ).setOnClickListener( this );
        findViewById( R.id.btnSendText ).setOnClickListener( this );
    }

    @Override
    public void onClick(View view) {

        int btnClick = view.getId();

        //calling part
        if (btnClick == R.id.btnStartPhoneCall) {

          String pNumber  = con.getHomeNumber();
            // Build the Uri for the phone number
            Uri numUri = Uri.parse( "tel:" + pNumber );
            // Your application needs the CALL_PHONE permission for this intent
            Intent i = new Intent( Intent.ACTION_CALL ); // Actually makes the call
            // Set the Uri as the intent data
            i.setData( numUri );

            if (i.resolveActivity( getPackageManager() ) != null) {
                if (ContextCompat.checkSelfPermission( this, Manifest.permission.CALL_PHONE ) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions( this, new String[]{Manifest.permission.CALL_PHONE}, MY_CALL_REQUEST );
                    //inform user if he/she not have the the permission to access call app
                    Toast.makeText(getApplicationContext(), "You don't have the permission to access the call app", Toast.LENGTH_LONG).show();

                } else {
                    startActivity( i );
                }
            }//2nd if
        }//1st if

        //texting part
        if (btnClick == R.id.btnSendText) {
            final String message = null;

          Intent  i = new Intent( Intent.ACTION_SENDTO );

            // Use the setData function to indicate the type of data that will be sent
            // this will help the system figure out what apps to include in the chooser
            i.setData( Uri.parse( "sms:"+con.getMobileNumber() ) );
            i.putExtra( "sms_body", message );

            if (i.resolveActivity( getPackageManager() ) != null) {
                if (ContextCompat.checkSelfPermission( this, Manifest.permission.SEND_SMS ) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions( this, new String[]{Manifest.permission.SEND_SMS}, MY_TEXT_SEND_REQUEST );
                    //inform user if he/she not have the the permission to access message app
                    Toast.makeText( getApplicationContext(), "You don't have the permission to access the text app", Toast.LENGTH_LONG ).show();
                } else {
                    startActivity( i );
                }
            }
        }
    }
}