package com.example.contact;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageDecoder;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.UUID;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;


public class AddEditGroupContact extends AppCompatActivity {

    private EditText groupName;
    private ImageView groupPhoto;
    private EditText groupMembers;

    private Button saveButton;

    private String imageFilePath;

    private static final int PICK_IMAGE_REQUEST_CODE = 1000;
    private static final int READ_EXTERNAL_STORAGE_REQUEST_CODE = 1001;

    //Key to send back contact information back and forth between MainActivity and this.

    public static final String GROUP_ID = "com.example.group.GROUP_ID";
    public static final String GROUP_NAME = "com.example.group.GROUP_NAME";
    public static final String GROUP_PHOTO = "com.example.group.GROUP_PHOTO";
    public static final String GROUP_MEMBERS = "com.example.group.GROUP_MEMBERS";

    //-----------------------------------onCreate-----------------------------------//
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_add_edit_group_contact);

        //Have layout move up when keyboard appears

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

        //Get IDs and assign to variables

        createIDs();

        //Determine intent

        determineIntent(); //Was activity opened to add or to edit a contact?

        //Disable save button if no values have been entered

        checkForValues();

        //Add listeners for EditText fields

        addListeners();

    }

    //-----------------------------------EditText IDs-----------------------------------//
    private void createIDs()
    {
        saveButton = findViewById(R.id.saveButton);
        //Contact information
        groupName = findViewById(R.id.groupNameInput);
        //contactPhoto = findViewById(R.id.contactPhoto);
        groupPhoto = findViewById(R.id.groupPhoto);
        groupMembers = findViewById(R.id.groupMembersInput);
    }

    private void determineIntent() //Determines intent. If add, set title to add, if edit, set title to edit and fill out fields with existing contact info
    {
        Intent intent = getIntent();

        //Determine if the contact information activity was opened with the intention of adding or editing a contact

        if(intent.hasExtra(GROUP_ID))
        {
            //Set title to specify edit

            setTitle("Edit Group");

            //Fill out fields with existing contact data

            groupName.setText(intent.getStringExtra(GROUP_NAME));

            //Get contact file path, convert to bitmap and set ImageView to bitmap

            if(intent.getStringExtra(GROUP_PHOTO) != null) //If an image exists for the contact
            {
                try //If there is no error in getting file, convert to bitmap and set ImageViewer to display it
                {
                    Bitmap selectedImage = BitmapFactory.decodeStream(new FileInputStream(new File(intent.getStringExtra(GROUP_PHOTO))));
                    //contactPhoto.setImageBitmap(selectedImage);
                    groupPhoto.setImageBitmap(selectedImage);
                }
                catch(FileNotFoundException e) //If there is an error in displaying file, set photo to default image
                {
                    e.printStackTrace();
                    //contactPhoto.setImageResource(R.drawable.ic_user);
                    groupPhoto.setImageResource(R.drawable.ic_user);
                }
            }
            else //If no image was passed, since no image was ever selected for contact, set image to default user photo
            {

            }
            groupMembers.setText(intent.getStringExtra(GROUP_MEMBERS));
        }
        else //If not edit, then activity was started to add contact
        {
            //Set title to specify add
            setTitle("Add Group");
        }
    }

    //-----------------------------------Listeners-----------------------------------//
    public void contactPhotoClicked(View view)
    {
        pickImage();
    }

    //If "cancel" button is pressed, return to main activity
    public void cancelButtonPressed(View view)
    {
        Intent openMainActivityIntent = new Intent(this, MainActivity.class);
        startActivity(openMainActivityIntent);
    }

    //When save button is pressed, save contact info
    public void saveButtonPressed(View view)
    {
        //Return to main activity with contact fields
        Intent data = new Intent();
        data.putExtra(GROUP_NAME, groupName.getText().toString());
        data.putExtra(GROUP_PHOTO, imageFilePath);
        data.putExtra(GROUP_MEMBERS, groupMembers.getText().toString());

        int id = getIntent().getIntExtra(GROUP_ID, -1); //If id is -1, ID is invalid.
        if(id != -1) //Only bring ID back to MainActivity if ID is valid (not -1)
        {
            data.putExtra(GROUP_ID, id);
        }

        //Result code specifies whether input was successful or not
        setResult(RESULT_OK, data);
        finish();
    }

    //-----------------------------------TextWatcher-----------------------------------//
    private void addListeners()
    {
        //set Listener for EditText fields
        groupName.addTextChangedListener(watcher);
        groupMembers.addTextChangedListener(watcher);
    }

    private TextWatcher watcher = new TextWatcher()
    {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) { }
        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3)
        {
            //Check if any values have been entered for any field
            checkForValues();
        }
        @Override
        public void afterTextChanged(Editable editable) { }
    };

    //Check if any field was filled out with a value
    private void checkForValues()
    {
        //If no values have been entered
        if(!groupName.getText().toString().isEmpty()
                || !groupMembers.getText().toString().isEmpty())
        {
            saveButton.setEnabled(true); //Enable save button
        }
        else //If values have been entered
        {
            saveButton.setEnabled(false); //Disable save button
        }
    }

    //-----------------------------------Implementation-----------------------------------//
    private void pickImage()
    {
        if(ActivityCompat.checkSelfPermission(this, READ_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED)
        {
            //Step 1: Create Intent
            // (ACTION_GET_CONTENT allows user to select particular kind of data and return it)
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);

            //Step 2: Set intent type
            // (This indicates the type of data the intent wants returned to it)
            intent.setType("image/*");

            //Extras (Elaborate on what this does)
            intent.putExtra("crop", "true");
            intent.putExtra("scale", true);
            intent.putExtra("aspectX", 16);
            intent.putExtra("aspectY", 9);

            //Step 4: Call startActivityForResult method
            // (Starts another activity and receives a result back from it)
            startActivityForResult(intent, PICK_IMAGE_REQUEST_CODE);
        }
        else
        {
            String permissions[] = {READ_EXTERNAL_STORAGE};
            ActivityCompat.requestPermissions(this, permissions, READ_EXTERNAL_STORAGE_REQUEST_CODE);
        }
    }

    //-----------------------------------Permissions-----------------------------------//
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        //Implements functionality for when PICK_IMAGE_REQUEST_CODE is sent

        //If startActivityForResult starts with no errors
        if(requestCode == PICK_IMAGE_REQUEST_CODE)
        {
            if(resultCode == RESULT_OK)
            {
                if(data.getData() != null)
                {
                    //Error

                    //contactPhoto.setImageURI(data.getData());
                    groupPhoto.setImageURI(data.getData());

                    //Uri -> Bitmap
                    ImageDecoder.Source source = ImageDecoder.createSource(this.getContentResolver(), data.getData());
                    try
                    {
                        Bitmap imageBitmap = ImageDecoder.decodeBitmap(source);
                        //Save image with random name to avoid duplicate names
                        imageFilePath = new ImageSaver(imageBitmap, getApplicationContext(), UUID.randomUUID().toString()).saveToInternalStorage();
                    }
                    catch(IOException e)
                    {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults)
    {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if(requestCode == READ_EXTERNAL_STORAGE_REQUEST_CODE)
        {
            //If the user allows permission
            if(grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                pickImage();
            }
        }
    }
}
