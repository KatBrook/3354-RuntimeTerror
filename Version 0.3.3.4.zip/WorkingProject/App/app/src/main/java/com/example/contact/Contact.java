package com.example.contact;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Contact
{
    @PrimaryKey(autoGenerate = true)
    private int id;

    private String contactImagePath;
    private String name;
    private String mobileNumber;
    private String homeNumber;
    private String workNumber;
    private String emailAddress;
    private String address;

    public Contact(String contactImagePath,
                   String name,
                   String mobileNumber,
                   String homeNumber,
                   String workNumber,
                   String emailAddress,
                   String address)
    {
        this.contactImagePath = contactImagePath;
        this.name = name;
        this.mobileNumber = mobileNumber;
        this.homeNumber = homeNumber;
        this.workNumber = workNumber;
        this.emailAddress = emailAddress;
        this.address = address;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public int getId()
    {
        return id;
    }

    public String getContactImagePath()
    {
        return contactImagePath;
    }

    public String getName()
    {
        return name;
    }

    public String getMobileNumber()
    {
        return mobileNumber;
    }

    public String getHomeNumber()
    {
        return homeNumber;
    }

    public String getWorkNumber()
    {
        return workNumber;
    }

    public String getEmailAddress()
    {
        return emailAddress;
    }

    public String getAddress()
    {
        return address;
    }
}
