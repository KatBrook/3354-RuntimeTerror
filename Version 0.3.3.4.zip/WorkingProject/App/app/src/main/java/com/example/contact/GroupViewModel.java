package com.example.contact;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

/*
Store and preserve data for user interface and communicate with repository
ViewModels survive configuration changes (i.e. rotating device)
Extends AndroidViewModel which is a subclass of ViewModel.
In AndroidViewModel, you get passed application and constructor which you can use whenever application context is needed
In ViewModel, you can pass context needed for ContactDB
Activity should only have reference to ViewModel, not repository

Activity -> ViewModel -> Repository -> Database
 */
public class GroupViewModel extends AndroidViewModel
{
    private GroupRepository repository;
    private LiveData<List<Group>> allGroups;

    public GroupViewModel(Application application)
    {
        super(application);
        repository = new GroupRepository(application);
        allGroups = repository.getAllGroups();
    }

    //Methods that activity will call in order to pass data to repository that will be stored in database
    public void insertGroup(Group group)
    {
        repository.insertGroup(group);
    }

    public void updateGroup(Group group)
    {
        repository.updateGroup(group);
    }

    public void deleteGroup(Group group)
    {
        repository.deleteGroup(group);
    }

    public LiveData<List<Group>> getAllGroups()
    {
        return allGroups;
    }
}
